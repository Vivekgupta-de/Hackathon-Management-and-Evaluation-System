// WebRTC signalling server. The video/audio itself flows directly between browsers (peer-to-peer);
// this server only passes the "handshake" messages and chat text.
const jwt = require('jsonwebtoken');
const { SECRET } = require('./middleware/auth');
const { canJoinRoom } = require('./rooms');

const MAX_PEOPLE = 6;

module.exports = function (io) {
  io.use((socket, next) => {
    try {
      socket.user = jwt.verify(socket.handshake.auth.token, SECRET);
      next();
    } catch (e) {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', (socket) => {
    socket.on('join', ({ room } = {}, cb = () => {}) => {
      if (!canJoinRoom(socket.user, room)) return cb({ error: 'You are not allowed to join this room' });
      const existing = [...(io.sockets.adapter.rooms.get(room) || [])];
      if (existing.length >= MAX_PEOPLE) return cb({ error: `Room is full (max ${MAX_PEOPLE} people)` });
      const peers = existing.map((id) => {
        const s = io.sockets.sockets.get(id);
        return { id, name: s.user.name, role: s.user.role };
      });
      socket.join(room);
      socket.data.room = room;
      cb({ me: socket.id, peers });
    });

    socket.on('signal', ({ to, data } = {}) => {
      const target = io.sockets.sockets.get(to);
      if (target && target.data.room && target.data.room === socket.data.room) {
        target.emit('signal', { from: socket.id, name: socket.user.name, role: socket.user.role, data });
      }
    });

    socket.on('chat', (text) => {
      const room = socket.data.room;
      if (room && String(text).trim()) {
        io.to(room).emit('chat', { name: socket.user.name, role: socket.user.role, text: String(text).slice(0, 500), time: Date.now() });
      }
    });

    socket.on('disconnecting', () => {
      const room = socket.data.room;
      if (room) socket.to(room).emit('peer-left', socket.id);
    });
  });
};
