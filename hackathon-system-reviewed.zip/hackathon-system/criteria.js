// The evaluation rubric (from the teacher's sheet). Total = 100 marks.
// Change values here and the whole system (judge form, validation, reports) updates.
module.exports = [
  { key: 'problem',      label: 'Problem understanding and relevance', max: 15, hint: 'Problem clarity, beneficiaries and alignment with the official problem statement' },
  { key: 'innovation',   label: 'Innovation and originality',          max: 15, hint: 'Novelty and meaningful improvement over existing approaches' },
  { key: 'technical',    label: 'Technical approach',                  max: 20, hint: 'Architecture, methodology, technology choice and technical soundness' },
  { key: 'feasibility',  label: 'Feasibility and implementability',    max: 15, hint: 'Practicality, resources, affordability and real-world implementation' },
  { key: 'prototype',    label: 'Prototype and demonstration',         max: 15, hint: 'Functionality, progress, reliability and relevance of the prototype' },
  { key: 'impact',       label: 'Impact and scalability',              max: 10, hint: 'Potential benefit, adoption and ability to scale' },
  { key: 'presentation', label: 'Presentation and response to questions', max: 10, hint: 'Clarity, teamwork, domain knowledge and quality of responses' }
];
