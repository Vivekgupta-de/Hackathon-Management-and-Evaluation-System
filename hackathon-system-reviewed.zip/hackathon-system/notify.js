// Sends OTPs by email (SMTP) or SMS (Twilio / Fast2SMS).
//
// If no provider is configured, the OTP is printed in the server console instead (development mode).
// In production (NODE_ENV=production) a missing provider is an error, so OTPs are never silently logged.
const APP_NAME = process.env.HACKATHON_NAME || 'Hackathon';

const isProd = () => process.env.NODE_ENV === 'production';

function devPrint(channel, target, code) {
  console.log(`\n  [DEV MODE] OTP for ${channel} ${target}: ${code}\n  (Configure SMTP / SMS provider in .env to send real OTPs)\n`);
  return { dev: true };
}

async function sendEmail(to, code, ttlMin, purpose) {
  if (!process.env.SMTP_HOST) {
    if (isProd()) throw new Error('Email is not configured (set SMTP_HOST, SMTP_USER, SMTP_PASS)');
    return devPrint('email', to, code);
  }
  let nodemailer;
  try { nodemailer = require('nodemailer'); } catch (e) { throw new Error('nodemailer is not installed. Run: npm install'); }
  const port = Number(process.env.SMTP_PORT) || 587;
  const transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure: port === 465,
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined
  });
  const what = purpose === 'reset' ? 'reset your password' : 'verify your email';
  await transport.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to,
    subject: `${code} is your ${APP_NAME} verification code`,
    text: `Your ${APP_NAME} OTP to ${what} is ${code}.\nIt is valid for ${ttlMin} minutes. Do not share it with anyone.`,
    html: `<div style="font-family:Arial,sans-serif;max-width:420px"><h2 style="margin:0 0 8px">${APP_NAME}</h2>
      <p>Use this OTP to ${what}:</p>
      <p style="font-size:30px;letter-spacing:6px;font-weight:700;margin:12px 0">${code}</p>
      <p style="color:#555">Valid for ${ttlMin} minutes. Do not share it with anyone.</p></div>`
  });
  return { dev: false };
}

async function sendSms(phone, code, ttlMin) {
  const provider = String(process.env.SMS_PROVIDER || '').toLowerCase();
  const cc = process.env.SMS_COUNTRY_CODE || '91';

  if (provider === 'twilio') {
    const sid = process.env.TWILIO_ACCOUNT_SID, token = process.env.TWILIO_AUTH_TOKEN;
    if (!sid || !token) throw new Error('Twilio is not configured (TWILIO_ACCOUNT_SID / TWILIO_AUTH_TOKEN)');
    const body = new URLSearchParams({ To: `+${cc}${phone}`, Body: `Your ${APP_NAME} OTP is ${code}. Valid for ${ttlMin} minutes. Do not share it.` });
    if (process.env.TWILIO_MESSAGING_SERVICE_SID) body.set('MessagingServiceSid', process.env.TWILIO_MESSAGING_SERVICE_SID);
    else body.set('From', process.env.TWILIO_FROM || '');
    const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: 'POST',
      headers: { Authorization: 'Basic ' + Buffer.from(`${sid}:${token}`).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
      signal: AbortSignal.timeout(10000)
    });
    if (!res.ok) throw new Error(`Twilio error ${res.status}: ${(await res.text()).slice(0, 200)}`);
    return { dev: false };
  }

  if (provider === 'fast2sms') {
    const key = process.env.FAST2SMS_API_KEY;
    if (!key) throw new Error('Fast2SMS is not configured (FAST2SMS_API_KEY)');
    const url = `https://www.fast2sms.com/dev/bulkV2?route=otp&variables_values=${code}&numbers=${phone}`;
    const res = await fetch(url, { headers: { authorization: key }, signal: AbortSignal.timeout(10000) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.return === false) throw new Error(`Fast2SMS error: ${data.message || res.status}`);
    return { dev: false };
  }

  if (isProd()) throw new Error('SMS is not configured (set SMS_PROVIDER=twilio or fast2sms in .env)');
  return devPrint('phone', phone, code);
}

exports.sendOtp = ({ channel, target, code, ttlMin, purpose }) =>
  channel === 'email' ? sendEmail(target, code, ttlMin, purpose) : sendSms(target, code, ttlMin);
