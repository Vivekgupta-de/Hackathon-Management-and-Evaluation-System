// One-time passwords: generate, deliver, verify. Codes are stored only as HMAC hashes.
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const db = require('./db');
const notify = require('./notify');
const { SECRET } = require('./middleware/auth');
const { httpError } = require('./utils');

const envNum = (key, fallback) => {
  const n = Number(process.env[key]);
  return process.env[key] !== undefined && process.env[key] !== '' && Number.isFinite(n) && n >= 0 ? n : fallback;
};
const TTL_MIN = envNum('OTP_TTL_MINUTES', 10) || 10;              // how long a code stays valid
const COOLDOWN_SEC = envNum('OTP_RESEND_SECONDS', 30);            // wait between two sends to the same target
const MAX_ATTEMPTS = 5;                                          // wrong guesses allowed per code
const MAX_PER_HOUR = 5;                                          // sends per target per hour
const TOKEN_SECRET = SECRET + ':otp-verified';                    // different key from login tokens

const hash = (channel, target, purpose, code) =>
  crypto.createHmac('sha256', SECRET).update(`${channel}|${target}|${purpose}|${code}`).digest('hex');

const latest = (channel, target, purpose) =>
  db.prepare('SELECT * FROM otps WHERE channel=? AND target=? AND purpose=? AND used=0 ORDER BY id DESC LIMIT 1').get(channel, target, purpose);

async function issue(channel, target, purpose) {
  const now = Date.now();
  const last = db.prepare('SELECT created_at FROM otps WHERE channel=? AND target=? AND purpose=? ORDER BY id DESC LIMIT 1').get(channel, target, purpose);
  if (last && now - last.created_at < COOLDOWN_SEC * 1000) {
    const wait = Math.ceil((COOLDOWN_SEC * 1000 - (now - last.created_at)) / 1000);
    throw httpError(429, `Please wait ${wait} seconds before requesting another OTP`);
  }
  const sent = db.prepare('SELECT COUNT(*) c FROM otps WHERE channel=? AND target=? AND created_at > ?').get(channel, target, now - 3600 * 1000).c;
  if (sent >= MAX_PER_HOUR) throw httpError(429, 'Too many OTP requests for this address. Please try again after an hour.');

  const code = String(crypto.randomInt(100000, 1000000));
  db.prepare('UPDATE otps SET used=1 WHERE channel=? AND target=? AND purpose=? AND used=0').run(channel, target, purpose);
  const r = db.prepare('INSERT INTO otps(channel,target,purpose,code_hash,expires_at,created_at) VALUES(?,?,?,?,?,?)')
    .run(channel, target, purpose, hash(channel, target, purpose, code), now + TTL_MIN * 60 * 1000, now);
  try {
    const out = await notify.sendOtp({ channel, target, code, ttlMin: TTL_MIN, purpose });
    return { dev: !!out.dev, expires_in_minutes: TTL_MIN, resend_after_seconds: COOLDOWN_SEC };
  } catch (e) {
    db.prepare('DELETE FROM otps WHERE id=?').run(Number(r.lastInsertRowid));
    console.error('OTP delivery failed:', e.message);
    throw httpError(502, `Could not send the OTP to this ${channel === 'email' ? 'email address' : 'mobile number'}. Please try again later.`);
  }
}

// Throws unless `code` is the current valid OTP. A correct code can be used only once.
function verify(channel, target, purpose, code) {
  code = String(code ?? '').trim();
  if (!/^\d{6}$/.test(code)) throw httpError(400, 'Enter the 6-digit OTP');
  const row = latest(channel, target, purpose);
  if (!row) throw httpError(400, 'No active OTP. Please request a new one.');
  const burn = () => db.prepare('UPDATE otps SET used=1 WHERE id=?').run(row.id);
  if (row.expires_at < Date.now()) { burn(); throw httpError(400, 'This OTP has expired. Please request a new one.'); }
  if (row.attempts >= MAX_ATTEMPTS) { burn(); throw httpError(429, 'Too many wrong attempts. Please request a new OTP.'); }
  const a = Buffer.from(hash(channel, target, purpose, code)), b = Buffer.from(row.code_hash);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    db.prepare('UPDATE otps SET attempts = attempts + 1 WHERE id=?').run(row.id);
    const left = MAX_ATTEMPTS - row.attempts - 1;
    if (left <= 0) burn();
    throw httpError(400, left > 0 ? `Incorrect OTP. ${left} attempt${left === 1 ? '' : 's'} left.` : 'Incorrect OTP. Please request a new one.');
  }
  burn();
}

// After a successful verify the browser gets a short-lived proof that is checked again at registration.
const verifiedToken = (channel, target, purpose) =>
  jwt.sign({ typ: 'otp-ok', ch: channel, t: target, p: purpose }, TOKEN_SECRET, { expiresIn: '30m' });

function assertVerified(token, channel, target, purpose) {
  const what = channel === 'email' ? 'email address' : 'mobile number';
  try {
    const d = jwt.verify(String(token || ''), TOKEN_SECRET);
    if (d.typ === 'otp-ok' && d.ch === channel && d.t === target && d.p === purpose) return;
  } catch (e) { /* fall through */ }
  throw httpError(400, `Please verify your ${what} with an OTP (verification may have expired - verify again)`);
}

// housekeeping: drop old rows once a day
const cleanup = () => db.prepare('DELETE FROM otps WHERE created_at < ?').run(Date.now() - 24 * 3600 * 1000);
cleanup();
setInterval(cleanup, 3600 * 1000).unref();

module.exports = { issue, verify, verifiedToken, assertVerified };
