// Who is allowed in which video room?
//   "helpdesk"   -> every logged-in user
//   "team-<id>"  -> that team, its mentor, its judges, and the admin
const db = require('./db');

function statusOf(userId) {
  const u = db.prepare('SELECT status FROM users WHERE id = ?').get(userId);
  return u ? u.status : null;
}

function canJoinRoom(user, room) {
  if (room === 'helpdesk') return statusOf(user.id) !== null;
  const m = /^team-(\d+)$/.exec(room || '');
  if (!m) return false;
  const team = db.prepare('SELECT * FROM teams WHERE id = ?').get(Number(m[1]));
  if (!team) return false;
  if (user.role === 'admin') return true;
  if (statusOf(user.id) !== 'approved' && user.role !== 'team') return false;
  if (user.role === 'team') return team.user_id === user.id;
  if (user.role === 'mentor') return team.mentor_id === user.id;
  if (user.role === 'judge') return !!db.prepare('SELECT 1 FROM judge_assignments WHERE judge_id=? AND team_id=?').get(user.id, team.id);
  return false;
}

function roomsFor(user) {
  const rooms = [{ id: 'helpdesk', label: 'Help desk (open to everyone)' }];
  let teams = [];
  if (user.role === 'admin') teams = db.prepare('SELECT id, team_name FROM teams ORDER BY team_name').all();
  else if (user.role === 'team') teams = db.prepare('SELECT id, team_name FROM teams WHERE user_id = ?').all(user.id);
  else if (statusOf(user.id) === 'approved' && user.role === 'mentor') teams = db.prepare('SELECT id, team_name FROM teams WHERE mentor_id = ?').all(user.id);
  else if (statusOf(user.id) === 'approved' && user.role === 'judge')
    teams = db.prepare('SELECT t.id, t.team_name FROM teams t JOIN judge_assignments a ON a.team_id=t.id WHERE a.judge_id=?').all(user.id);
  teams.forEach((t) => rooms.push({ id: `team-${t.id}`, label: `Team room: ${t.team_name}` }));
  return rooms;
}

module.exports = { canJoinRoom, roomsFor };
