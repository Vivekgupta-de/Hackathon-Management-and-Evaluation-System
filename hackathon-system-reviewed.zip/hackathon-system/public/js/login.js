let role = new URLSearchParams(location.search).get('role') || 'team';
function setRole(r) {
  role = r;
  $$('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.r === r));
  $('#go').textContent = 'Log in as ' + r;
  $('#reg').innerHTML = r === 'admin' ? '' : `New here? <a href="register-${r}.html">Register as a ${r}</a>`;
}
$$('#tabs button').forEach((b) => (b.onclick = () => setRole(b.dataset.r)));
setRole(role);

$('#f').onsubmit = (e) => {
  e.preventDefault();
  if (!e.target.reportValidity()) return;
  submitWith($('#go'), async () => {
    const d = formData(e.target);
    const r = await api('/login', { method: 'POST', body: { ...d, role } });
    saveLogin(r.token, r.user);
    location.href = role === 'admin' ? 'admin.html' : role + '.html';
  });
};
