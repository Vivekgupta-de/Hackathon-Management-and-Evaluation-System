requireRole('admin');

const TABS = [['overview', 'Overview'], ['teams', 'Teams'], ['mentors', 'Mentors'], ['judges', 'Judges'], ['submissions', 'Submissions'], ['evaluations', 'Evaluations'], ['reports', 'Reports']];
let S = {};            // all data
let tab = location.hash.slice(1) || 'overview';
let evalRound = '';    // filter on Evaluations tab

async function loadAll() {
  const [stats, teams, mentors, judges, subs, evals, board] = await Promise.all([
    api('/admin/stats'), api('/admin/teams'), api('/admin/mentors'), api('/admin/judges'),
    api('/admin/submissions'), api('/admin/evaluations'), api('/admin/leaderboard')
  ]);
  S = { stats, teams, mentors, judges, subs, evals, board };
  draw();
}

function draw() {
  if (!TABS.some((t) => t[0] === tab)) tab = 'overview';
  $('#app').innerHTML = `<div class="page-head"><h1>Admin dashboard</h1></div>
    <div class="tabs no-print" role="tablist">${TABS.map(([k, l]) => `<button data-tab="${k}" class="${k === tab ? 'on' : ''}">${l}</button>`).join('')}</div>
    <div id="panel">${views[tab]()}</div>`;
  $$('[data-tab]').forEach((b) => (b.onclick = () => { tab = b.dataset.tab; location.hash = tab; draw(); }));
  wire();
}

const statusButtons = (u) => `
  ${u.status !== 'approved' ? `<button class="btn ok sm" data-status="approved" data-id="${u.id}">Approve</button>` : ''}
  ${u.status !== 'rejected' ? `<button class="btn bad sm" data-status="rejected" data-id="${u.id}">Reject</button>` : ''}
  <button class="btn ghost sm" data-del="${u.id}">Delete</button>`;

const views = {
  overview() {
    const st = S.stats;
    const box = (label, o) => `<div class="stat"><b>${o.total}</b><span>${label}</span><div class="small muted" style="margin-top:6px">${o.pending} pending &middot; ${o.approved} approved &middot; ${o.rejected} rejected</div></div>`;
    return `<div class="cols" style="grid-template-columns:repeat(auto-fill,minmax(230px,1fr))">
      ${box('Teams', st.teams)}${box('Mentors', st.mentors)}${box('Judges', st.judges)}
      <div class="stat"><b>${st.submissions}</b><span>Submissions</span></div>
      <div class="stat"><b>${st.evaluations}</b><span>Judge score sheets</span></div></div>
    <div class="card" style="margin-top:22px"><h3>Hackathon settings</h3>
      <div class="grid2"><div class="field"><label for="round">Scoring round currently open for judges</label>
        <select id="round"><option value="1" ${st.settings.current_round === 1 ? 'selected' : ''}>Round 1 (initial assessment)</option><option value="2" ${st.settings.current_round === 2 ? 'selected' : ''}>Round 2 (refined solution)</option></select></div>
      <div class="field"><label for="pub">Show results to teams</label>
        <select id="pub"><option value="0" ${!st.settings.results_published ? 'selected' : ''}>Hidden</option><option value="1" ${st.settings.results_published ? 'selected' : ''}>Published</option></select></div></div>
      <button class="btn" id="saveSet">Save settings</button></div>
    <div class="card"><h3>Typical workflow</h3><ol class="muted" style="margin:0;padding-left:1.2em">
      <li>Approve registered teams, mentors and judges.</li><li>Assign a mentor and judges to every team (Teams tab).</li>
      <li>Judges score Round 1. Mentors coach teams.</li><li>Switch the open round to Round 2 and judges score again.</li>
      <li>Open Reports to see totals and rank, download CSV, then publish results.</li></ol></div>`;
  },

  teams() {
    const mentors = S.mentors.filter((m) => m.status === 'approved');
    return `<div class="tablewrap"><table><thead><tr><th>Team</th><th>Leader</th><th>Status</th><th>Mentor</th><th>Judges</th><th>Actions</th></tr></thead><tbody>
      ${S.teams.map((t) => `<tr>
        <td><b>${esc(t.team_name)}</b><br><span class="small muted">${esc(t.college)}</span></td>
        <td>${esc(t.leader_name)}${liLink(t.leader_linkedin)}<br><span class="small muted">${esc(t.email)}${t.email_verified ? ' <span title="Verified by OTP" style="color:var(--ok)">&#10003;</span>' : ''}<br>${esc(t.phone || '')}${t.phone_verified ? ' <span title="Verified by OTP" style="color:var(--ok)">&#10003;</span>' : ''}</span></td>
        <td>${badge(t.status)}</td>
        <td><select data-mentor="${t.id}" aria-label="Mentor for ${esc(t.team_name)}"><option value="">- none -</option>${mentors.map((m) => `<option value="${m.id}" ${t.mentor_id === m.id ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select></td>
        <td>${t.judges.map((j) => `<span class="chip">${esc(j.name)}</span>`).join('') || '<span class="muted small">none</span>'}<br><button class="btn ghost sm" data-judges="${t.id}">Assign judges</button></td>
        <td><div class="actions"><button class="btn ghost sm" data-view="${t.id}">View</button>${statusButtons({ id: t.user_id, status: t.status })}</div></td></tr>`).join('') || '<tr><td colspan="6" class="muted">No teams yet.</td></tr>'}
    </tbody></table></div>`;
  },

  mentors() {
    return `<div class="tablewrap"><table><thead><tr><th>Name</th><th>Organisation</th><th>Skills</th><th>Experience</th><th>Availability</th><th>Teams</th><th>Status</th><th>Actions</th></tr></thead><tbody>
      ${S.mentors.map((m) => `<tr><td><b>${esc(m.name)}</b>${liLink(m.linkedin)}<br><span class="small muted">${esc(m.email)}${m.email_verified ? ' <span title="Verified by OTP" style="color:var(--ok)">&#10003;</span>' : ''}<br>${esc(m.phone || '')}${m.phone_verified ? ' <span title="Verified by OTP" style="color:var(--ok)">&#10003;</span>' : ''}</span></td>
        <td>${esc(m.organization)}<br><span class="small muted">${esc(m.designation || '')}</span></td>
        <td>${(m.skills || '').split(',').filter(Boolean).map((s) => `<span class="chip">${esc(s.trim())}</span>`).join('')}</td>
        <td>${esc(m.experience_years)} yrs<br><span class="small muted">${esc(m.experience_desc || '')}</span></td>
        <td>${esc(m.availability)}</td><td class="num">${m.team_count}</td><td>${badge(m.status)}</td>
        <td><div class="actions">${statusButtons(m)}</div></td></tr>`).join('') || '<tr><td colspan="8" class="muted">No mentors yet.</td></tr>'}
    </tbody></table></div>`;
  },

  judges() {
    return `<div class="tablewrap"><table><thead><tr><th>Name</th><th>Organisation</th><th>Expertise</th><th>Experience</th><th>Teams</th><th>Status</th><th>Actions</th></tr></thead><tbody>
      ${S.judges.map((j) => `<tr><td><b>${esc(j.name)}</b>${liLink(j.linkedin)}<br><span class="small muted">${esc(j.email)}${j.email_verified ? ' <span title="Verified by OTP" style="color:var(--ok)">&#10003;</span>' : ''}<br>${esc(j.phone || '')}${j.phone_verified ? ' <span title="Verified by OTP" style="color:var(--ok)">&#10003;</span>' : ''}</span></td>
        <td>${esc(j.organization)}<br><span class="small muted">${esc(j.designation || '')}</span></td>
        <td>${(j.expertise || '').split(',').filter(Boolean).map((s) => `<span class="chip">${esc(s.trim())}</span>`).join('')}</td>
        <td>${esc(j.experience_years)} yrs<br><span class="small muted">${esc(j.experience_desc || '')}</span></td>
        <td class="num">${j.team_count}</td><td>${badge(j.status)}</td>
        <td><div class="actions">${statusButtons(j)}</div></td></tr>`).join('') || '<tr><td colspan="7" class="muted">No judges yet.</td></tr>'}
    </tbody></table></div>`;
  },

  submissions() {
    return `<div class="tablewrap"><table><thead><tr><th>Team</th><th>Title</th><th>File / link</th><th>Added</th></tr></thead><tbody>
      ${S.subs.map((s) => `<tr><td><b>${esc(s.team_name)}</b></td><td>${esc(s.title)}</td>
        <td>${s.original_name ? `<button class="btn ghost sm" data-dl="${s.id}" data-name="${esc(s.original_name)}">Download ${esc(s.original_name)}</button>` : ''} ${s.link ? `<a href="${esc(s.link)}" target="_blank" rel="noopener">Open link</a>` : ''}</td>
        <td class="small muted">${esc(fmtDate(s.created_at))}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">No submissions yet.</td></tr>'}
    </tbody></table></div>`;
  },

  evaluations() {
    const crit = S.board.criteria;
    const list = S.evals.filter((e) => !evalRound || String(e.round) === evalRound);
    return `<div class="field" style="max-width:240px"><label for="rf">Filter by round</label><select id="rf"><option value="">All rounds</option><option value="1" ${evalRound === '1' ? 'selected' : ''}>Round 1</option><option value="2" ${evalRound === '2' ? 'selected' : ''}>Round 2</option></select></div>
    <div class="tablewrap"><table><thead><tr><th>Team</th><th>Judge</th><th class="num">Round</th>${crit.map((c) => `<th class="num" title="${esc(c.label)}">${esc(c.label.split(' ')[0])} /${c.max}</th>`).join('')}<th class="num">Total /100</th><th>Feedback</th></tr></thead><tbody>
      ${list.map((e) => `<tr><td><b>${esc(e.team_name)}</b></td><td>${esc(e.judge_name)}</td><td class="num">${e.round}</td>${crit.map((c) => `<td class="num">${e[c.key]}</td>`).join('')}<td class="num"><b>${e.total}</b></td><td class="small">${esc(e.feedback)}</td></tr>`).join('') || `<tr><td colspan="${crit.length + 5}" class="muted">No scores yet.</td></tr>`}
    </tbody></table></div>`;
  },

  reports() {
    const { criteria, rows } = S.board;
    return `<div class="page-head no-print" style="margin-bottom:14px"><p class="muted" style="margin:0;max-width:46em">Team total = average of all judges' totals (out of 100). Final = Round 2 average when Round 2 is scored, otherwise Round 1.</p>
      <div class="actions"><button class="btn" id="csv">Download CSV</button><button class="btn ghost" id="print">Print</button></div></div>
    <div class="tablewrap"><table><thead><tr><th class="num">Rank</th><th>Team</th><th>College</th><th class="num">Judges scored</th><th class="num">Round 1</th><th class="num">Round 2</th><th class="num">Final /100</th>${criteria.map((c) => `<th class="num" title="${esc(c.label)}">${esc(c.label.split(' ')[0])} /${c.max}</th>`).join('')}</tr></thead><tbody>
      ${rows.map((r) => `<tr><td class="num"><b>${num(r.rank)}</b></td><td><b>${esc(r.team_name)}</b><br><span class="small muted">${esc(r.project_title || '')}</span></td><td>${esc(r.college)}</td>
        <td class="num">${r.final_round === 2 ? r.r2_count : r.r1_count}/${r.judges_assigned}</td><td class="num">${num(r.round1)}</td><td class="num">${num(r.round2)}</td>
        <td class="num" style="font-size:1.15rem"><b>${num(r.final)}</b></td>${criteria.map((c) => `<td class="num">${num(r.breakdown[c.key])}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${criteria.length + 7}" class="muted">No approved teams yet.</td></tr>`}
    </tbody></table></div>`;
  }
};

function teamDetails(t) {
  modal(`<h2 style="font-size:1.6rem">${esc(t.team_name)}</h2>
    <p>${badge(t.status)} <span class="muted">${esc(t.college)}, ${esc(t.department)}${t.city ? ', ' + esc(t.city) : ''}</span></p>
    <p><b>Leader:</b> ${esc(t.leader_name)}${t.leader_gender ? ` (${esc(t.leader_gender)})` : ''}${liLink(t.leader_linkedin)}<br><span class="small muted">${esc(t.email)}, ${esc(t.phone || '')}</span></p>
    <p><b>Members:</b></p>
    <ul style="margin:0 0 1em;padding-left:1.2em">${t.members.map((m) => `<li>${esc(m.name)}${m.gender ? ` (${esc(m.gender)})` : ''}${liLink(m.linkedin)}<span class="small muted">${m.email ? ' ' + esc(m.email) : ''}${m.phone ? ' ' + esc(m.phone) : ''}</span></li>`).join('')}</ul>
    <p><b>Problem statement:</b> ${esc(t.problem_statement)}</p>
    <p><b>Project:</b> ${esc(t.project_title)}</p><p>${esc(t.project_idea)}</p>
    <p><b>Mentor:</b> ${esc(t.mentor_name || 'not assigned')}<br><b>Judges:</b> ${t.judges.map((j) => esc(j.name)).join(', ') || 'none'}</p>
    <a class="btn amber" href="video.html?room=team-${t.id}">Join this team's video room</a>`);
}

function judgeModal(t) {
  const approved = S.judges.filter((j) => j.status === 'approved');
  const assigned = new Set(t.judges.map((j) => j.id));
  const m = modal(`<h2 style="font-size:1.5rem">Assign judges to ${esc(t.team_name)}</h2>
    ${approved.length ? approved.map((j) => `<label style="font-weight:500;display:flex;gap:10px;align-items:center;padding:6px 0"><input type="checkbox" style="width:auto" value="${j.id}" ${assigned.has(j.id) ? 'checked' : ''}> ${esc(j.name)} <span class="muted small">${esc(j.organization || '')}</span></label>`).join('') : '<p class="muted">No approved judges yet. Approve judges first.</p>'}
    <p><button class="btn" id="saveJ">Save</button></p>`);
  $('#saveJ', m).onclick = () => submitWith($('#saveJ', m), async () => {
    const ids = $$('input:checked', m).map((i) => Number(i.value));
    await api(`/admin/teams/${t.id}/judges`, { method: 'PUT', body: { judge_ids: ids } });
    toast('Judges updated'); m.close(); loadAll();
  });
}

function wire() {
  const act = async (fn, msg) => { try { await fn(); if (msg) toast(msg); await loadAll(); } catch (e) { toast(e.message, true); } };
  $$('[data-status]').forEach((b) => (b.onclick = () => act(() => api(`/admin/users/${b.dataset.id}/status`, { method: 'PUT', body: { status: b.dataset.status } }), 'Status updated')));
  $$('[data-del]').forEach((b) => (b.onclick = () => { if (confirm('Delete this account and everything linked to it? This cannot be undone.')) act(() => api(`/admin/users/${b.dataset.del}`, { method: 'DELETE' }), 'Deleted'); }));
  $$('[data-mentor]').forEach((s) => (s.onchange = () => act(() => api(`/admin/teams/${s.dataset.mentor}/mentor`, { method: 'PUT', body: { mentor_id: s.value || null } }), 'Mentor updated')));
  $$('[data-judges]').forEach((b) => (b.onclick = () => judgeModal(S.teams.find((t) => t.id === Number(b.dataset.judges)))));
  $$('[data-view]').forEach((b) => (b.onclick = () => teamDetails(S.teams.find((t) => t.id === Number(b.dataset.view)))));
  $$('[data-dl]').forEach((b) => (b.onclick = () => downloadFile(`/submissions/${b.dataset.dl}/download`, b.dataset.name)));
  const ss = $('#saveSet');
  if (ss) ss.onclick = () => act(() => api('/admin/settings', { method: 'PUT', body: { current_round: Number($('#round').value), results_published: $('#pub').value === '1' } }), 'Settings saved');
  const rf = $('#rf');
  if (rf) rf.onchange = () => { evalRound = rf.value; draw(); };
  const csv = $('#csv');
  if (csv) csv.onclick = () => downloadFile('/admin/report.csv', 'hackathon-results.csv');
  const pr = $('#print');
  if (pr) pr.onclick = () => window.print();
}

loadAll().catch((e) => { if (e.message !== 'redirect') $('#app').innerHTML = `<div class="banner rejected">${esc(e.message)}</div>`; });
