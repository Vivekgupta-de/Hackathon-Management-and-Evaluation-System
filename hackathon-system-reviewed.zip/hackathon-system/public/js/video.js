// Peer-to-peer video calls using WebRTC. server/socket.js only relays the handshake messages.
if (!getToken()) location.href = 'login.html';

const room = new URLSearchParams(location.search).get('room');
const ICE = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }] };
const peers = {};      // socketId -> { pc, tile, queue }
let local = null;      // local MediaStream
let socket = null;
let screenStream = null;

async function lobby() {
  $('#lobby').classList.remove('hidden');
  const rooms = await api('/video/rooms');
  $('#roomList').innerHTML = rooms.map((r) => `<div class="card" style="margin:0;display:flex;justify-content:space-between;align-items:center;gap:12px"><b>${esc(r.label)}</b><a class="btn amber" href="video.html?room=${encodeURIComponent(r.id)}">Join</a></div>`).join('');
}

function tile(id, name, stream, muted) {
  const d = document.createElement('div');
  d.className = 'tile';
  d.id = 'tile-' + id;
  d.innerHTML = `<video autoplay playsinline ${muted ? 'muted' : ''}></video><span class="who"></span>`;
  $('.who', d).textContent = name;
  if (stream) $('video', d).srcObject = stream;
  $('#grid').appendChild(d);
  return d;
}

function createPeer(id, name) {
  if (peers[id]) return peers[id];
  const pc = new RTCPeerConnection(ICE);
  const entry = { pc, tile: tile(id, name, null, false), queue: Promise.resolve() };
  peers[id] = entry;
  if (local) local.getTracks().forEach((t) => pc.addTrack(t, local));
  else { pc.addTransceiver('audio', { direction: 'recvonly' }); pc.addTransceiver('video', { direction: 'recvonly' }); }
  pc.ontrack = (e) => { $('video', entry.tile).srcObject = e.streams[0]; };
  pc.onicecandidate = (e) => { if (e.candidate) socket.emit('signal', { to: id, data: { candidate: e.candidate } }); };
  return entry;
}

function removePeer(id) {
  const p = peers[id];
  if (!p) return;
  p.pc.close();
  p.tile.remove();
  delete peers[id];
}

async function handleSignal({ from, name, data }) {
  const entry = createPeer(from, name);
  entry.queue = entry.queue.then(async () => {
    const pc = entry.pc;
    if (data.sdp) {
      await pc.setRemoteDescription(data.sdp);
      if (data.sdp.type === 'offer') {
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        socket.emit('signal', { to: from, data: { sdp: pc.localDescription } });
      }
    } else if (data.candidate) {
      try { await pc.addIceCandidate(data.candidate); } catch (e) { /* ignore late candidates */ }
    }
  }).catch((e) => console.error('signal error', e));
}

async function start() {
  $('#call').classList.remove('hidden');
  $('#roomTitle').textContent = room === 'helpdesk' ? 'Help desk' : 'Team room ' + room.replace('team-', '#');

  if (!navigator.mediaDevices) { toast('Camera needs https:// or http://localhost', true); }
  try { local = await navigator.mediaDevices.getUserMedia({ video: true, audio: true }); }
  catch (e) {
    try { local = await navigator.mediaDevices.getUserMedia({ audio: true }); toast('Camera not available. Joined with audio only.', true); }
    catch (e2) { toast('No camera or microphone. You can watch and use chat.', true); }
  }
  tile('me', (getUser().name || 'You') + ' (you)', local, true);

  socket = io({ auth: { token: getToken() } });
  socket.on('connect_error', (e) => { $('#status').textContent = 'Could not connect: ' + e.message; });
  socket.on('connect', () => {
    socket.emit('join', { room }, async (res) => {
      if (res.error) { $('#status').textContent = res.error; toast(res.error, true); return; }
      $('#status').textContent = res.peers.length ? `Connected. ${res.peers.length + 1} people in the room.` : 'Connected. Waiting for others to join...';
      // the newcomer calls everyone already in the room
      for (const p of res.peers) {
        const entry = createPeer(p.id, p.name);
        const offer = await entry.pc.createOffer();
        await entry.pc.setLocalDescription(offer);
        socket.emit('signal', { to: p.id, data: { sdp: entry.pc.localDescription } });
      }
    });
  });
  socket.on('signal', handleSignal);
  socket.on('peer-left', (id) => { removePeer(id); $('#status').textContent = 'Someone left the room.'; });
  socket.on('chat', (m) => {
    const d = document.createElement('div');
    d.className = 'm';
    d.innerHTML = `<b>${esc(m.name)}</b> <span class="muted small">${esc(m.role)} &middot; ${new Date(m.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span><br>${esc(m.text)}`;
    $('#log').appendChild(d);
    $('#log').scrollTop = 1e9;
  });
}

$('#cf').onsubmit = (e) => {
  e.preventDefault();
  const v = $('#ct').value.trim();
  if (v && socket) socket.emit('chat', v);
  $('#ct').value = '';
};

$('#mic').onclick = () => {
  if (!local || !local.getAudioTracks().length) return;
  const t = local.getAudioTracks()[0];
  t.enabled = !t.enabled;
  $('#mic').textContent = t.enabled ? 'Mute mic' : 'Unmute mic';
};
$('#cam').onclick = () => {
  if (!local || !local.getVideoTracks().length) return;
  const t = local.getVideoTracks()[0];
  t.enabled = !t.enabled;
  $('#cam').textContent = t.enabled ? 'Stop camera' : 'Start camera';
};

async function swapVideo(track) {
  for (const p of Object.values(peers)) {
    const sender = p.pc.getSenders().find((s) => s.track && s.track.kind === 'video');
    if (sender) await sender.replaceTrack(track);
  }
  const mine = $('#tile-me video');
  if (mine) mine.srcObject = new MediaStream([track, ...(local ? local.getAudioTracks() : [])]);
}
$('#share').onclick = async () => {
  try {
    if (screenStream) { screenStream.getTracks().forEach((t) => t.stop()); return; }
    if (!navigator.mediaDevices.getDisplayMedia) return toast('Screen sharing is not supported in this browser', true);
    screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
    const track = screenStream.getVideoTracks()[0];
    await swapVideo(track);
    $('#share').textContent = 'Stop sharing';
    track.onended = async () => {
      screenStream = null;
      $('#share').textContent = 'Share screen';
      if (local && local.getVideoTracks()[0]) await swapVideo(local.getVideoTracks()[0]);
    };
  } catch (e) { toast('Screen share cancelled', true); }
};
$('#hang').onclick = () => { location.href = 'video.html'; };
window.addEventListener('beforeunload', () => { if (socket) socket.disconnect(); if (local) local.getTracks().forEach((t) => t.stop()); });

if (room) start(); else lobby().catch((e) => toast(e.message, true));
