// Used by both the mentor and judge registration pages
const kind = location.pathname.includes('judge') ? 'judge' : 'mentor';

bindPhone($('#phone'));
const emailOtp = attachOtp($('#email'), 'email');
const phoneOtp = attachOtp($('#phone'), 'phone');

$('#f').onsubmit = (e) => {
  e.preventDefault();
  if (!e.target.reportValidity()) return;
  if (!phoneOk($('#phone').value)) { $('#phone').focus(); return toast('Mobile number must be exactly 10 digits', true); }
  if (!linkedinOk($('#linkedin').value)) { $('#linkedin').focus(); return toast('LinkedIn: use a link like https://www.linkedin.com/in/your-name, or leave it empty', true); }
  if (!emailOtp.isVerified()) { $('#email').focus(); return toast('Please verify your email with the OTP', true); }
  if (!phoneOtp.isVerified()) { $('#phone').focus(); return toast('Please verify your mobile number with the OTP', true); }
  submitWith($('#go'), async () => {
    const body = { ...formData(e.target), email_token: emailOtp.token(), phone_token: phoneOtp.token() };
    const r = await api('/register/' + kind, { method: 'POST', body });
    $('#f').classList.add('hidden');
    $('#done').classList.remove('hidden');
    $('#doneMsg').textContent = r.message;
    window.scrollTo(0, 0);
  });
};
