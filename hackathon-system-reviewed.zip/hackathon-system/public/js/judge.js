requireRole('judge');
let D;

const evalFor = (t, round) => t.evaluations.find((e) => e.round === round);

function render() {
  const { user, teams, criteria, current_round } = D;
  const maxTotal = criteria.reduce((s, c) => s + c.max, 0);
  $('#app').innerHTML = `
    <div class="page-head"><div><h1>Judge dashboard</h1><div class="muted">${esc(user.name)}${liLink(user.linkedin)} &middot; ${esc(user.organization || '')}</div></div><div>Status: ${badge(user.status)}</div></div>
    ${user.status === 'pending' ? '<div class="banner pending">Your application is waiting for admin approval. Teams will be assigned to you afterwards.</div>' : ''}
    ${user.status === 'approved' ? `<div class="banner ok">Scoring is open for <b>Round ${current_round}</b>. Use the same rubric (${maxTotal} marks) for every team.</div>` : ''}
    ${user.status === 'approved' && !teams.length ? '<p class="muted">No teams assigned to you yet.</p>' : ''}
    <div class="stack">${teams.map((t) => {
      const cur = evalFor(t, current_round), r1 = evalFor(t, 1), r2 = evalFor(t, 2);
      return `<div class="card"><div class="page-head" style="margin-bottom:10px"><div><h3 style="margin:0">${esc(t.team_name)}</h3><div class="small muted">${esc(t.college)} &middot; ${esc(t.problem_statement)}</div></div>
        <div class="actions"><a class="btn ghost sm" href="video.html?room=team-${t.id}">Video call</a>
        <button class="btn sm" data-eval="${t.id}">${cur ? 'Edit' : 'Enter'} Round ${current_round} marks</button></div></div>
        <p><b>${esc(t.project_title)}</b><br>${esc(t.project_idea)}</p>
        <p class="small muted">Members: ${esc(t.leader_name)}, ${t.members.map((m) => esc(m.name)).join(', ')}</p>
        ${t.submissions.length ? `<div class="actions" style="margin-bottom:10px">${t.submissions.map((s) => s.original_name
          ? `<button class="btn ghost sm" data-dl="${s.id}" data-name="${esc(s.original_name)}">${esc(s.title)}</button>`
          : `<a class="btn ghost sm" target="_blank" rel="noopener" href="${esc(s.link)}">${esc(s.title)} (link)</a>`).join('')}</div>` : ''}
        <div>Your marks: Round 1 ${r1 ? `<b>${r1.total}/100</b>` : '<span class="muted">not scored</span>'} &middot; Round 2 ${r2 ? `<b>${r2.total}/100</b>` : '<span class="muted">not scored</span>'}</div>
      </div>`;
    }).join('')}</div>`;
  $$('[data-dl]').forEach((b) => (b.onclick = () => downloadFile(`/submissions/${b.dataset.dl}/download`, b.dataset.name)));
  $$('[data-eval]').forEach((b) => (b.onclick = () => openForm(teams.find((t) => t.id === Number(b.dataset.eval)))));
}

function openForm(t) {
  const { criteria, current_round } = D;
  const prev = evalFor(t, current_round);
  const m = modal(`<h2 style="font-size:1.6rem">${esc(t.team_name)}: Round ${current_round}</h2>
    <p class="muted small">Enter whole numbers. Each box has its own maximum.</p>
    <form id="ef" novalidate>
      ${criteria.map((c) => `<div class="score-row"><div><label for="s_${c.key}" style="margin:0">${esc(c.label)} <span class="muted">(max ${c.max})</span></label><div class="hint">${esc(c.hint)}</div></div>
        <input id="s_${c.key}" data-max="${c.max}" type="number" min="0" max="${c.max}" step="1" value="${prev ? prev[c.key] : ''}" required></div>`).join('')}
      <div class="total-box"><span>Total for this judge</span><span><b id="tot">0</b> / ${criteria.reduce((s, c) => s + c.max, 0)}</span></div>
      <div class="field"><label for="fb">Feedback for the team</label><textarea id="fb" placeholder="Concise, specific and actionable feedback for improvement">${esc(prev ? prev.feedback : '')}</textarea></div>
      <button class="btn" id="save">Save marks</button>
    </form>`);
  const recalc = () => {
    let s = 0;
    $$('[data-max]', m).forEach((i) => { const v = parseInt(i.value, 10); if (!isNaN(v)) s += v; });
    $('#tot', m).textContent = s;
  };
  $$('[data-max]', m).forEach((i) => i.addEventListener('input', recalc));
  recalc();
  $('#ef', m).onsubmit = (e) => {
    e.preventDefault();
    const scores = {};
    for (const c of criteria) {
      const i = $('#s_' + c.key, m);
      const v = i.value === '' ? NaN : Number(i.value);
      if (!Number.isInteger(v) || v < 0 || v > c.max) { i.focus(); return toast(`${c.label}: enter 0 to ${c.max}`, true); }
      scores[c.key] = v;
    }
    submitWith($('#save', m), async () => {
      const r = await api('/judge/evaluate', { method: 'POST', body: { team_id: t.id, round: current_round, scores, feedback: $('#fb', m).value } });
      toast(r.message);
      m.close();
      load();
    });
  };
}

async function load() { D = await api('/judge/me'); render(); }
load().catch((e) => { $('#app').innerHTML = `<div class="banner rejected">${esc(e.message)}</div>`; });
