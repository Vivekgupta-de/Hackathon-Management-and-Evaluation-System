$('#problem_statement').innerHTML = '<option value="">Choose a problem statement</option>' +
  HK.problems.map((p) => `<option value="${esc(p.id + ' - ' + p.title)}">${esc(p.id + ' - ' + p.title)}</option>`).join('');

// OTP verification for the team leader's email and mobile number
bindPhone($('#phone'));
const emailOtp = attachOtp($('#email'), 'email');
const phoneOtp = attachOtp($('#phone'), 'phone');

// ---- members ----
let count = 0;
function addMember() {
  if (count >= 3) return toast('Maximum 3 members besides the leader', true);
  count++;
  const n = count;
  const d = document.createElement('div');
  d.className = 'member';
  d.innerHTML = `<div class="member-title">Member ${n}</div>
    <div class="grid3">
      <div class="field"><label for="mn${n}">Full name</label><input id="mn${n}" class="mn" ${n === 1 ? 'required' : ''}></div>
      <div class="field"><label for="mg${n}">Gender</label><select id="mg${n}" class="mg" ${n === 1 ? 'required' : ''}><option value="">Select</option><option>Female</option><option>Male</option><option>Other</option></select></div>
      <div class="field"><label for="mp${n}">Mobile (10 digits)</label><input id="mp${n}" class="mp" type="tel" placeholder="optional"></div>
    </div>
    <div class="grid2">
      <div class="field"><label for="me${n}">Email</label><input id="me${n}" class="me" type="email" placeholder="optional"></div>
      <div class="field"><label for="ml${n}">LinkedIn profile <span class="muted">(optional)</span></label><input id="ml${n}" class="ml" inputmode="url" placeholder="https://www.linkedin.com/in/username"></div>
    </div>`;
  $('#members').appendChild(d);
  bindPhone($('.mp', d));
  if (count === 3) $('#addMember').classList.add('hidden');
}
$('#addMember').onclick = addMember;
addMember();

// ---- rule: at least 1 female member (leader or any member) ----
function hasFemale() {
  const genders = [$('#leader_gender').value, ...$$('.mg').map((s) => (s.closest('.member') && $('.mn', s.closest('.member')).value.trim() ? s.value : ''))];
  return genders.includes('Female');
}
function updateRule() {
  const ok = hasFemale();
  const el = $('#femaleRule');
  el.className = 'banner rule-note ' + (ok ? 'ok' : 'pending');
  el.textContent = ok ? 'Rule satisfied: your team has at least 1 female member.' : 'Rule: your team needs at least 1 female member (select Gender for the leader and each member).';
}
document.addEventListener('input', (e) => { if (e.target.matches('.mn')) updateRule(); });
document.addEventListener('change', (e) => { if (e.target.matches('#leader_gender, .mg')) updateRule(); });
updateRule();

$('#f').onsubmit = (e) => {
  e.preventDefault();
  if (!e.target.reportValidity()) return;
  const fail = (msg, el) => { if (el) el.focus(); toast(msg, true); };

  if (!phoneOk($('#phone').value)) return fail('Mobile number must be exactly 10 digits', $('#phone'));
  if (!linkedinOk($('#linkedin').value)) return fail('Leader LinkedIn: use a link like https://www.linkedin.com/in/your-name, or leave it empty', $('#linkedin'));

  const members = $$('.member').map((m) => ({ name: $('.mn', m).value.trim(), gender: $('.mg', m).value, email: $('.me', m).value.trim(), phone: $('.mp', m).value.trim(), linkedin: $('.ml', m).value.trim() }));
  for (const [i, m] of members.entries()) {
    const row = $$('.member')[i];
    if (!m.name) continue;
    if (!m.gender) return fail(`Member ${i + 1}: please select gender`, $('.mg', row));
    if (m.phone && !phoneOk(m.phone)) return fail(`Member ${i + 1}: mobile number must be exactly 10 digits`, $('.mp', row));
    if (!linkedinOk(m.linkedin)) return fail(`Member ${i + 1}: LinkedIn link is not valid (or leave it empty)`, $('.ml', row));
  }
  if (!hasFemale()) return fail('Every team must include at least 1 female member', $('#leader_gender'));
  if (!emailOtp.isVerified()) return fail('Please verify your email with the OTP', $('#email'));
  if (!phoneOtp.isVerified()) return fail('Please verify your mobile number with the OTP', $('#phone'));

  submitWith($('#go'), async () => {
    const fd = new FormData(e.target);
    fd.append('members', JSON.stringify(members.filter((m) => m.name)));
    fd.append('email_token', emailOtp.token());
    fd.append('phone_token', phoneOtp.token());
    if (!$('#document').files.length) fd.delete('document');
    const r = await api('/register/team', { method: 'POST', form: fd });
    $('#f').classList.add('hidden');
    $('#done').classList.remove('hidden');
    $('#doneMsg').textContent = r.message;
    window.scrollTo(0, 0);
  });
};
