let channel = 'email', email = '', timer = null;

function cooldown(sec) {
  const b = $('#resend');
  clearInterval(timer);
  let left = sec;
  const tick = () => { b.disabled = left > 0; b.textContent = left > 0 ? `Resend OTP in ${left}s` : 'Resend OTP'; if (left-- <= 0) clearInterval(timer); };
  tick();
  if (sec > 0) timer = setInterval(tick, 1000);
}

async function sendOtp(btn) {
  await submitWith(btn, async () => {
    const r = await api('/forgot-password/send', { method: 'POST', body: { email, channel } });
    $('#f1').classList.add('hidden');
    $('#f2').classList.remove('hidden');
    $('#sentMsg').textContent = r.message + (r.dev ? ' (Dev mode: the OTP is printed in the server console.)' : '');
    cooldown(r.resend_after_seconds || 30);
    $('#code').focus();
  });
}

$('#f1').onsubmit = (e) => {
  e.preventDefault();
  if (!e.target.reportValidity()) return;
  email = $('#email').value.trim().toLowerCase();
  channel = $('input[name="channel"]:checked').value;
  sendOtp($('#send'));
};

$('#resend').onclick = () => { email = $('#email').value.trim().toLowerCase(); sendOtp($('#resend')); };
$('#code').addEventListener('input', (e) => { e.target.value = e.target.value.replace(/\D/g, '').slice(0, 6); });

$('#f2').onsubmit = (e) => {
  e.preventDefault();
  if (!e.target.reportValidity()) return;
  if ($('#password').value !== $('#password2').value) return toast('The two passwords do not match', true);
  submitWith($('#reset'), async () => {
    const r = await api('/forgot-password/reset', { method: 'POST', body: { email, channel, code: $('#code').value, password: $('#password').value } });
    $('#f2').classList.add('hidden');
    $('#done').classList.remove('hidden');
    $('#doneMsg').textContent = r.message;
  });
};
