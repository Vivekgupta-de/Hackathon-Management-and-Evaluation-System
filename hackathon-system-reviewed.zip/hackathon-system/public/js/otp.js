// Reusable OTP widget. attachOtp(input, 'email' | 'phone') adds "Send OTP" / "Verify" controls under the input.
//   const emailOtp = attachOtp($('#email'), 'email');
//   emailOtp.isVerified()  -> true when the CURRENT value of the input has been verified
//   emailOtp.token()       -> proof to send to the server with the registration form
function attachOtp(input, channel) {
  const label = channel === 'email' ? 'email' : 'mobile number';
  const field = input.closest('.field');
  const box = document.createElement('div');
  box.className = 'otp-box';
  box.innerHTML = `
    <div class="otp-row">
      <button type="button" class="btn ghost sm" data-send>Send OTP</button>
      <span class="otp-status small" role="status" aria-live="polite"></span>
    </div>
    <div class="otp-row hidden" data-entry>
      <input class="otp-code" inputmode="numeric" maxlength="6" autocomplete="one-time-code" placeholder="6-digit OTP" aria-label="OTP sent to your ${label}">
      <button type="button" class="btn sm" data-verify>Verify</button>
    </div>`;
  field.appendChild(box);

  const sendBtn = $('[data-send]', box), verifyBtn = $('[data-verify]', box);
  const entry = $('[data-entry]', box), code = $('.otp-code', box), status = $('.otp-status', box);
  let verified = null;      // { target, token }
  let timer = null;

  const value = () => (channel === 'email' ? input.value.trim().toLowerCase() : input.value.trim());
  const valueOk = () => (channel === 'email' ? /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value()) : phoneOk(value()));
  const say = (msg, cls = '') => { status.textContent = msg; status.className = 'otp-status small ' + cls; };

  function cooldown(sec) {
    clearInterval(timer);
    let left = sec;
    const tick = () => {
      sendBtn.disabled = left > 0;
      sendBtn.textContent = left > 0 ? `Resend in ${left}s` : 'Resend OTP';
      if (left-- <= 0) clearInterval(timer);
    };
    tick();
    if (sec > 0) timer = setInterval(tick, 1000);
  }

  function reset() {
    verified = null;
    input.readOnly = false;
    clearInterval(timer);
    sendBtn.disabled = false; sendBtn.textContent = 'Send OTP';
    sendBtn.classList.remove('hidden');
    entry.classList.add('hidden'); code.value = '';
    say('');
  }

  // typing a different value after verification (or while an OTP is pending) starts over
  input.addEventListener('input', () => {
    if (verified && verified.target !== value()) reset();
    else if (!verified && !entry.classList.contains('hidden')) { entry.classList.add('hidden'); say(''); }
  });

  sendBtn.onclick = async () => {
    if (!valueOk()) { input.focus(); return toast(channel === 'email' ? 'Enter a valid email address first' : 'Enter a valid 10-digit mobile number first', true); }
    sendBtn.disabled = true; sendBtn.textContent = 'Sending...';
    try {
      const r = await api('/otp/send', { method: 'POST', body: { channel, target: value() } });
      entry.classList.remove('hidden'); code.value = ''; code.focus();
      say(r.dev ? `OTP generated. Dev mode: look for it in the server console (terminal).` : `OTP sent to your ${label}. Valid for ${r.expires_in_minutes} minutes.`);
      cooldown(r.resend_after_seconds || 30);
    } catch (e) {
      toast(e.message, true);
      sendBtn.disabled = false; sendBtn.textContent = 'Send OTP';
    }
  };

  verifyBtn.onclick = async () => {
    verifyBtn.disabled = true;
    try {
      const r = await api('/otp/verify', { method: 'POST', body: { channel, target: value(), code: code.value } });
      verified = { target: value(), token: r.token };
      input.readOnly = true;
      clearInterval(timer);
      entry.classList.add('hidden');
      sendBtn.classList.add('hidden');
      status.className = 'otp-status small verified';
      status.innerHTML = `&#10003; ${channel === 'email' ? 'Email' : 'Mobile number'} verified <button type="button" class="linklike" data-change>Change</button>`;
      $('[data-change]', status).onclick = () => { reset(); input.focus(); };
    } catch (e) { toast(e.message, true); code.select(); }
    verifyBtn.disabled = false;
  };
  code.addEventListener('input', () => { code.value = code.value.replace(/\D/g, '').slice(0, 6); });
  code.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); verifyBtn.click(); } });

  return {
    isVerified: () => !!verified && verified.target === value(),
    token: () => (verified ? verified.token : '')
  };
}
