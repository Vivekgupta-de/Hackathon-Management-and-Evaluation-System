// Shared helpers used by every page.
const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];

const getToken = () => localStorage.getItem('hk_token');
const getUser = () => { try { return JSON.parse(localStorage.getItem('hk_user')); } catch (e) { return null; } };
function saveLogin(token, user) { localStorage.setItem('hk_token', token); localStorage.setItem('hk_user', JSON.stringify(user)); }
function logout() { localStorage.removeItem('hk_token'); localStorage.removeItem('hk_user'); location.href = 'login.html'; }

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const badge = (s) => `<span class="badge ${esc(s)}">${esc(s)}</span>`;
const fmtDate = (d) => (d ? new Date(String(d).replace(' ', 'T') + (String(d).includes('Z') ? '' : 'Z')).toLocaleString() : '');
const num = (v) => (v === null || v === undefined ? '-' : v);

async function api(path, { method = 'GET', body, form } = {}) {
  const headers = {};
  if (getToken()) headers.Authorization = 'Bearer ' + getToken();
  let payload;
  if (form) payload = form;
  else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const res = await fetch('/api' + path, { method, headers, body: payload });
  let data = {};
  try { data = await res.json(); } catch (e) { /* not json */ }
  if (res.status === 401 && !path.startsWith('/login')) { logout(); throw new Error('Please log in again'); }
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// Download a protected file (needs the login token, so a plain link will not work)
async function downloadFile(path, filename) {
  const res = await fetch('/api' + path, { headers: { Authorization: 'Bearer ' + getToken() } });
  if (!res.ok) { let m = 'Download failed'; try { m = (await res.json()).error; } catch (e) {} return toast(m, true); }
  const blob = await res.blob();
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename || 'file';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

function toast(msg, isErr) {
  const t = document.createElement('div');
  t.className = 'toast' + (isErr ? ' err' : '');
  t.setAttribute('role', 'status');
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), isErr ? 5000 : 3000);
}

function modal(html) {
  const o = document.createElement('div');
  o.className = 'overlay';
  o.innerHTML = `<div class="modal" role="dialog" aria-modal="true"><button class="x" aria-label="Close">&times;</button>${html}</div>`;
  const close = () => { o.remove(); document.removeEventListener('keydown', onKey); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  o.addEventListener('mousedown', (e) => { if (e.target === o) close(); });
  $('.x', o).onclick = close;
  document.body.appendChild(o);
  o.close = close;
  return o;
}

function requireRole(role) {
  const u = getUser();
  if (!getToken() || !u || u.role !== role) { location.href = 'login.html'; throw new Error('redirect'); }
}

function renderNav() {
  const u = getUser();
  const home = (h) => (location.pathname.endsWith('index.html') || location.pathname === '/' ? h : 'index.html' + h);
  const dash = u ? (u.role === 'admin' ? 'admin.html' : u.role + '.html') : '';
  $('#nav').innerHTML = `<header class="nav"><div class="nav-in">
    <a class="brand" href="index.html"><span class="mark"></span>${esc(HK.name)}</a>
    <nav aria-label="Main">
      <a href="${home('#about')}">About</a>
      <a href="${home('#problems')}">Problems</a>
      <a href="${home('#timeline')}">Timeline</a>
      <a href="${home('#prizes')}">Prizes</a>
      <a href="${home('#faq')}">FAQ</a>
      ${u ? '' : `<details class="menu"><summary>Register</summary><div class="drop">
        <a href="register-team.html">As a team</a><a href="register-mentor.html">As a mentor</a><a href="register-judge.html">As a judge</a></div></details>`}
      ${u ? `<a href="video.html">Video call</a><a href="${dash}">Dashboard</a><a href="#" id="logoutLink">Log out (${esc(u.name.split(' ')[0])})</a>` : '<a class="cta" href="login.html">Log in</a>'}
    </nav></div></header>`;
  const l = $('#logoutLink');
  if (l) l.onclick = (e) => { e.preventDefault(); logout(); };
  const f = $('#footer');
  if (f) f.innerHTML = `<footer class="foot">${esc(HK.name)} &middot; ${esc(HK.organiser)}, ${esc(HK.college)} &middot; <a style="color:#c9d4f7" href="mailto:${esc(HK.contact)}">${esc(HK.contact)}</a></footer>`;
}

// Turn a <form> into a plain object
function formData(form) { return Object.fromEntries(new FormData(form).entries()); }

// Submit helper: disables button, shows errors as toast
async function submitWith(btn, fn) {
  const old = btn.textContent;
  btn.disabled = true; btn.textContent = 'Please wait...';
  try { await fn(); } catch (e) { if (e.message !== 'redirect') toast(e.message, true); }
  btn.disabled = false; btn.textContent = old;
}

document.addEventListener('DOMContentLoaded', renderNav);

// ---------- Mobile number: exactly 10 digits, numbers only ----------
function cleanPhone(v) {
  let d = String(v || '').replace(/\D/g, '');
  if (d.length === 12 && d.startsWith('91')) d = d.slice(2);      // pasted "+91 98765 43210"
  else if (d.length === 11 && d.startsWith('0')) d = d.slice(1);   // pasted "098765 43210"
  return d.slice(0, 10);
}
function bindPhone(input) {
  input.setAttribute('inputmode', 'numeric');
  input.setAttribute('pattern', '[0-9]{10}');
  input.setAttribute('title', 'Enter exactly 10 digits');
  input.addEventListener('input', () => { input.value = cleanPhone(input.value); });
}
const phoneOk = (v) => /^\d{10}$/.test(String(v || '').trim());

// ---------- LinkedIn (always optional) ----------
const LINKEDIN_RE = /^(https?:\/\/)?((www|[a-z]{2,3})\.)?linkedin\.com\/in\/[^\s\/?#]+\/?([?#]\S*)?$/i;
const linkedinOk = (v) => !String(v || '').trim() || LINKEDIN_RE.test(String(v).trim());
const liLink = (u) => (u && /^https?:\/\//i.test(u)
  ? `<a class="li" href="${esc(u)}" target="_blank" rel="noopener noreferrer">LinkedIn</a>` : '');
