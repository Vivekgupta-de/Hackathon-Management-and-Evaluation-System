// ============================================================
//  EDIT THIS FILE to customise the home page content.
//  (No backend change needed - just save and refresh.)
// ============================================================
window.HK = {
  name: 'CodeSprint 2027',
  tagline: 'Two days to turn a real campus problem into a working prototype.',
  organiser: 'Department of Computer Science',
  college: 'Your College Name',
  venue: 'Main Auditorium and Computer Labs',
  start: '2027-01-01T09:00:00',   // Hackathon date: 1 January 2027
  end: '2027-01-02T17:00:00',
  regClose: '20 December 2026',   // shown on the home page countdown
  contact: 'hackathon@yourcollege.edu',

  about: [
    'CodeSprint 2027 is a college-level hackathon where student teams pick a real problem, build a working prototype and defend it in front of industry judges and faculty mentors.',
    'It runs in two rounds. In Round 1 judges assess your problem understanding, plan and early prototype and give written feedback. You then work with a mentor to improve, and in Round 2 judges score your refined solution independently on the same 100-mark rubric.'
  ],

  problems: [
    { id: 'PS-01', title: 'Smart attendance and campus safety', domain: 'AI / IoT', text: 'Build a low-cost way to mark attendance and flag unsafe situations on campus without invading privacy.' },
    { id: 'PS-02', title: 'Affordable healthcare access', domain: 'HealthTech', text: 'Help rural patients book, prepare for and follow up on doctor visits using only a basic smartphone.' },
    { id: 'PS-03', title: 'Farmers and fair prices', domain: 'AgriTech', text: 'Give small farmers real-time market prices, crop advice and a way to sell directly to buyers.' },
    { id: 'PS-04', title: 'Clean water and waste', domain: 'Sustainability', text: 'Monitor water quality or manage waste collection for a hostel, village or small town.' },
    { id: 'PS-05', title: 'Learning for every student', domain: 'EdTech', text: 'Create tools that help students in low-bandwidth areas learn, practise and get feedback in their own language.' },
    { id: 'PS-06', title: 'Open innovation', domain: 'Any domain', text: 'Have your own idea? Pick this and clearly explain the problem, who benefits and why it matters.' }
  ],

  rules: [
    'Teams must have 2 to 4 members. Every member must be a currently enrolled student.',
    'Every team must include a minimum of 1 female member (the team leader or any team member). Registrations without one are not accepted.',
    'Registration needs a valid email address and a 10-digit mobile number, both verified with an OTP. LinkedIn profiles are optional.',
    'Each team registers once through the team leader. Team names must be unique.',
    'Your project must address one of the listed problem statements (or PS-06 with a clear description).',
    'Use open-source libraries and public APIs freely, but the core solution must be built by your team during the event.',
    'Plagiarism or reusing a previously built project leads to disqualification.',
    'Every team is assigned a mentor. Please attend the mentoring session before Round 2.',
    'Judges score both rounds on the same 100-mark rubric. The decision of the judges is final.',
    'Be respectful to teammates, mentors, judges and organisers at all times.'
  ],

  timeline: [
    { date: '1 Nov 2026', title: 'Registrations open', text: 'Teams, mentors and judges can register on this website.' },
    { date: '20 Dec 2026', title: 'Registrations close', text: 'Last day to register and upload your idea document.' },
    { date: '25 Dec 2026', title: 'Approvals and assignments', text: 'Admin approves teams and assigns mentors and judges.' },
    { date: '1 Jan 2027, 9:00 AM', title: 'Hackathon begins, Round 1', text: 'Present your problem, plan and current prototype to your judges.' },
    { date: '1 Jan 2027, 2:00 PM', title: 'Mentoring session', text: 'Work with your mentor (in person or on the video call feature here).' },
    { date: '2 Jan 2027, 10:00 AM', title: 'Round 2', text: 'Present your refined solution. Judges score independently.' },
    { date: '2 Jan 2027, 4:00 PM', title: 'Results and prizes', text: 'Final scores are published and winners are announced.' }
  ],


  prizes: [
    { place: 'Second place', amount: '₹25,000', extra: 'Trophy and certificates' },
    { place: 'Winner', amount: '₹50,000', extra: 'Trophy, certificates and internship interviews', first: true },
    { place: 'Third place', amount: '₹10,000', extra: 'Trophy and certificates' }
  ],

  faq: [
    { q: 'Who can participate?', a: 'Any currently enrolled college student. Teams can mix departments and years.' },
    { q: 'Does my team need a female member?', a: 'Yes. Every team must include at least 1 female member. She can be the team leader or any of the other members.' },
    { q: 'Why do I need to verify with an OTP?', a: 'The team leader, mentors and judges must verify their email and 10-digit mobile number with a one-time password during registration, so organisers can reach you reliably.' },
    { q: 'I forgot my password. What do I do?', a: 'Open the Log in page and click "Forgot password?". We will send an OTP to your registered email or mobile number so you can set a new password.' },
    { q: 'Is there a registration fee?', a: 'No. Registration is free.' },
    { q: 'I registered. What happens next?', a: 'Your status is Pending until the admin approves your team. Log in any time to check your status.' },
    { q: 'How are marks decided?', a: 'Every assigned judge scores you out of 100 using the rubric below. Your team total is the average of all judges.' },
    { q: 'How do I talk to my mentor?', a: 'Log in, open your dashboard and click "Join video call". Your mentor, judges and admin can join the same team room.' },
    { q: 'Can I update my submission later?', a: 'Yes. Upload new files or links from your team dashboard until the admin closes submissions.' }
  ]
};
