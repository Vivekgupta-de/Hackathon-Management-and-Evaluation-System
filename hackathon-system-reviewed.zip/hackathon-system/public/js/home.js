document.title = HK.name + ' | ' + HK.college;
$('#hName').textContent = HK.name;
$('#hTag').textContent = HK.tagline;
const fmt = (d) => new Date(d).toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' });
$('#hMeta').textContent = `${fmt(HK.start)} to ${fmt(HK.end)}  |  ${HK.venue}`;
$('#hBtns').innerHTML = getUser()
  ? `<a class="btn amber" href="${getUser().role === 'admin' ? 'admin' : getUser().role}.html">Go to my dashboard</a>`
  : `<a class="btn amber" href="register-team.html">Register your team</a><a class="btn ghost" style="color:#fff;border-color:#4a61a8" href="register-mentor.html">Mentor</a><a class="btn ghost" style="color:#fff;border-color:#4a61a8" href="register-judge.html">Judge</a>`;

$('#aboutText').innerHTML = HK.about.map((p) => `<p>${esc(p)}</p>`).join('');
$('#themes').innerHTML = HK.problems.map((p) => `<div class="theme"><small>${esc(p.id)} &middot; ${esc(p.domain)}</small><h3>${esc(p.title)}</h3><p class="muted" style="margin:0">${esc(p.text)}</p></div>`).join('');
$('#rulesList').innerHTML = HK.rules.map((r) => `<li>${esc(r)}</li>`).join('');
$('#tl').innerHTML = HK.timeline.map((t) => `<div class="ev"><div class="date">${esc(t.date)}</div><h3>${esc(t.title)}</h3><p class="muted">${esc(t.text)}</p></div>`).join('');
$('#prizeBox').innerHTML = HK.prizes.map((p) => `<div class="prize ${p.first ? 'first' : ''}"><h3>${esc(p.place)}</h3><span class="amt">${esc(p.amount)}</span><span class="small">${esc(p.extra)}</span></div>`).join('');
$('#faqList').innerHTML = HK.faq.map((f) => `<details class="faq"><summary>${esc(f.q)}</summary><p>${esc(f.a)}</p></details>`).join('');

api('/criteria').then((c) => {
  $('#rubric').innerHTML = c.map((x) => `<tr><td>${esc(x.label)}</td><td>${x.max}</td><td>${esc(x.hint)}</td></tr>`).join('') +
    `<tr><td><b>Total</b></td><td>${c.reduce((s, x) => s + x.max, 0)}</td><td>Same rubric for every team, in both rounds</td></tr>`;
}).catch(() => {});

// live countdown
function tick() {
  const start = new Date(HK.start), end = new Date(HK.end), now = new Date();
  let target = start, title = 'Starts in', foot = `Registrations are open until ${HK.regClose}.`;
  if (now >= start && now < end) { target = end; title = 'Ends in'; foot = 'The hackathon is live!'; }
  if (now >= end) { $('#clockTitle').textContent = 'The hackathon has ended'; foot = 'Thank you to everyone who took part.'; target = now; }
  else $('#clockTitle').textContent = title;
  $('#clockFoot').textContent = foot;
  const s = Math.max(0, Math.floor((target - now) / 1000));
  $('#cd').textContent = Math.floor(s / 86400);
  $('#ch').textContent = String(Math.floor(s % 86400 / 3600)).padStart(2, '0');
  $('#cm').textContent = String(Math.floor(s % 3600 / 60)).padStart(2, '0');
  $('#cs').textContent = String(s % 60).padStart(2, '0');
}
tick(); setInterval(tick, 1000);
