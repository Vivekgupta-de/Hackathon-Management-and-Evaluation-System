requireRole('team');
let D;

const subRow = (s) => `<tr><td>${esc(s.title)}</td>
  <td>${s.original_name ? `<button class="btn ghost sm" data-dl="${s.id}" data-name="${esc(s.original_name)}">Download ${esc(s.original_name)}</button>` : ''}
      ${s.link ? `<a href="${esc(s.link)}" target="_blank" rel="noopener">Open link</a>` : ''}</td>
  <td class="small muted">${esc(fmtDate(s.created_at))}</td></tr>`;

function resultsHtml(r) {
  if (!r) return `<div class="card"><h3>Results</h3><p class="muted">Scores and judge feedback will appear here after the organisers publish the results.</p></div>`;
  const s = r.summary;
  if (!s || s.final === null) return `<div class="card"><h3>Results</h3><p class="muted">Your team has not been scored yet.</p></div>`;
  const byRound = (n) => r.evaluations.filter((e) => e.round === n);
  const block = (n) => {
    const list = byRound(n);
    if (!list.length) return '';
    return `<h3 style="margin-top:20px">Round ${n} feedback</h3>` + list.map((e, i) => `
      <div class="card" style="background:var(--paper)"><b>Judge ${i + 1}: ${e.total}/100</b>
      <p class="small muted" style="margin:6px 0">${r.criteria.map((c) => `${esc(c.label)} ${e[c.key]}/${c.max}`).join(' &middot; ')}</p>
      <p style="margin:0">${esc(e.feedback) || '<span class="muted">No written feedback.</span>'}</p></div>`).join('');
  };
  return `<div class="card"><h3>Results</h3>
    <div style="display:flex;gap:32px;flex-wrap:wrap;align-items:flex-end">
      <div><div class="bigscore">${s.final}<span class="muted" style="font-size:1.4rem">/100</span></div><div class="muted">Final total marks (Round ${s.final_round})</div></div>
      <div><b>Round 1:</b> ${num(s.round1)}/100 &nbsp; <b>Round 2:</b> ${num(s.round2)}/100</div>
      ${s.rank ? `<div><b>Rank:</b> ${s.rank}</div>` : ''}
    </div>
    <div class="tablewrap" style="margin-top:18px"><table><thead><tr><th>Criterion</th><th class="num">Average marks</th><th class="num">Out of</th></tr></thead><tbody>
      ${r.criteria.map((c) => `<tr><td>${esc(c.label)}</td><td class="num">${num(s.breakdown[c.key])}</td><td class="num">${c.max}</td></tr>`).join('')}
    </tbody></table></div>
    ${block(1)}${block(2)}</div>`;
}

function render() {
  const { user, team, members, mentor, submissions, results } = D;
  $('#app').innerHTML = `
    <div class="page-head"><div><h1>${esc(team.team_name)}</h1><div class="muted">${esc(team.college)} &middot; ${esc(team.department)}</div></div>
      <div>Status: ${badge(user.status)}</div></div>
    ${user.status === 'pending' ? '<div class="banner pending">Your team is waiting for admin approval. You can already upload documents.</div>' : ''}
    ${user.status === 'approved' ? `<div class="banner ok">Your team is approved. Scoring is currently in <b>Round ${D.current_round}</b>.</div>` : ''}
    <div class="cols">
      <div class="card"><h3>Team members</h3>
        <p style="margin:0 0 6px"><b>${esc(user.name)}</b> <span class="chip">Leader</span>${liLink(user.linkedin)}<br><span class="small muted">${esc(user.email)} &middot; ${esc(user.phone)}</span></p>
        ${members.map((m) => `<p style="margin:0 0 6px"><b>${esc(m.name)}</b>${liLink(m.linkedin)}<br><span class="small muted">${esc(m.email || '')} ${esc(m.phone || '')}</span></p>`).join('')}
      </div>
      <div class="card"><h3>Your mentor</h3>
        ${mentor ? `<p><b>${esc(mentor.name)}</b>${liLink(mentor.linkedin)}<br><span class="small muted">${esc(mentor.organization || '')}</span><br>${esc(mentor.email)}<br>${esc(mentor.phone || '')}</p>
          ${(mentor.skills || '').split(',').filter(Boolean).map((s) => `<span class="chip">${esc(s.trim())}</span>`).join('')}`
          : '<p class="muted">A mentor has not been assigned yet.</p>'}
        <p style="margin-top:14px"><a class="btn amber" href="video.html?room=team-${team.id}">Join video call</a></p>
        <p class="hint">Your mentor, judges and the admin can join this same room.</p>
      </div>
    </div>
    <div class="card"><h3>Project idea</h3>
      <form id="ideaForm"><div class="field"><label>Problem statement</label><input value="${esc(team.problem_statement)}" disabled></div>
      <div class="field"><label for="pt">Project title</label><input id="pt" name="project_title" value="${esc(team.project_title)}" required></div>
      <div class="field"><label for="pi">Idea</label><textarea id="pi" name="project_idea" required>${esc(team.project_idea)}</textarea></div>
      <button class="btn sm">Save changes</button></form></div>
    <div class="card"><h3>Submissions</h3>
      ${submissions.length ? `<div class="tablewrap"><table><thead><tr><th>Title</th><th>File / link</th><th>Added</th></tr></thead><tbody>${submissions.map(subRow).join('')}</tbody></table></div>` : '<p class="muted">Nothing submitted yet.</p>'}
      <form id="subForm" style="margin-top:18px"><div class="grid3">
        <div class="field"><label for="st">Title</label><input id="st" name="title" placeholder="e.g. Round 1 slides" required></div>
        <div class="field"><label for="sf">File</label><input id="sf" name="file" type="file"></div>
        <div class="field"><label for="sl">or link</label><input id="sl" name="link" type="url" placeholder="https://github.com/..."></div>
      </div><button class="btn sm">Add submission</button></form></div>
    ${resultsHtml(results)}`;

  $('#ideaForm').onsubmit = (e) => { e.preventDefault(); submitWith($('button', e.target), async () => { const r = await api('/team/idea', { method: 'PUT', body: formData(e.target) }); toast(r.message); }); };
  $('#subForm').onsubmit = (e) => {
    e.preventDefault();
    submitWith($('button', e.target), async () => {
      const fd = new FormData(e.target);
      if (!$('#sf').files.length) fd.delete('file');
      await api('/team/submissions', { method: 'POST', form: fd });
      toast('Submission added');
      load();
    });
  };
  $$('[data-dl]').forEach((b) => (b.onclick = () => downloadFile(`/submissions/${b.dataset.dl}/download`, b.dataset.name)));
}

async function load() { D = await api('/team/me'); render(); }
load().catch((e) => { $('#app').innerHTML = `<div class="banner rejected">${esc(e.message)}</div>`; });
