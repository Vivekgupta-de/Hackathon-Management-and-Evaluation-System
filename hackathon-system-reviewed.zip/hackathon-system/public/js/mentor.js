requireRole('mentor');

async function load() {
  const { user, teams } = await api('/mentor/me');
  $('#app').innerHTML = `
    <div class="page-head"><div><h1>Mentor dashboard</h1><div class="muted">${esc(user.name)}${liLink(user.linkedin)} &middot; ${esc(user.organization || '')}</div></div><div>Status: ${badge(user.status)}</div></div>
    ${user.status === 'pending' ? '<div class="banner pending">Your application is waiting for admin approval. Once approved, teams assigned to you will appear here.</div>' : ''}
    <div class="card"><h3>Your profile</h3>
      <p class="muted" style="margin:0">Skills: ${(user.skills || '').split(',').filter(Boolean).map((s) => `<span class="chip">${esc(s.trim())}</span>`).join('')}<br>
      Experience: ${esc(user.experience_years)} years &middot; Availability: ${esc(user.availability)}</p></div>
    <h2 style="font-size:1.5rem">Assigned teams (${teams.length})</h2>
    ${user.status === 'approved' && !teams.length ? '<p class="muted">No teams assigned yet.</p>' : ''}
    <div class="stack">${teams.map((t) => `
      <div class="card"><div class="page-head" style="margin-bottom:10px"><div><h3 style="margin:0">${esc(t.team_name)}</h3><div class="small muted">${esc(t.college)}</div></div>
        <a class="btn amber" href="video.html?room=team-${t.id}">Join video call</a></div>
        <p><b>${esc(t.project_title)}</b> <span class="chip">${esc(t.problem_statement)}</span></p>
        <p>${esc(t.project_idea)}</p>
        <p class="small muted" style="margin:0 0 10px"><b>Leader:</b> ${esc(t.leader_name)}${liLink(t.leader_linkedin)} (${esc(t.leader_email)}, ${esc(t.leader_phone || '')})<br>
          <b>Members:</b> ${t.members.map((m) => esc(m.name) + liLink(m.linkedin)).join(', ')}</p>
        ${t.submissions.length ? `<div class="actions">${t.submissions.map((s) => s.original_name
          ? `<button class="btn ghost sm" data-dl="${s.id}" data-name="${esc(s.original_name)}">${esc(s.title)}: ${esc(s.original_name)}</button>`
          : `<a class="btn ghost sm" target="_blank" rel="noopener" href="${esc(s.link)}">${esc(s.title)} (link)</a>`).join('')}</div>` : '<span class="muted small">No submissions yet.</span>'}
      </div>`).join('')}</div>`;
  $$('[data-dl]').forEach((b) => (b.onclick = () => downloadFile(`/submissions/${b.dataset.dl}/download`, b.dataset.name)));
}
load().catch((e) => { $('#app').innerHTML = `<div class="banner rejected">${esc(e.message)}</div>`; });
