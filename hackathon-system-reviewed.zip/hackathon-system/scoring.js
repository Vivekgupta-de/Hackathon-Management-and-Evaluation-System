// All mark calculations live here.
const db = require('./db');
const CRITERIA = require('./criteria');

const round2 = (n) => Math.round(n * 100) / 100;
const avg = (arr) => (arr.length ? round2(arr.reduce((s, x) => s + x, 0) / arr.length) : null);

/**
 * Team total = AVERAGE of the totals given by all judges (out of 100), per round.
 * Final score = Round 2 average if Round 2 has been scored, otherwise Round 1 average.
 */
function leaderboard() {
  const teams = db.prepare(`
    SELECT t.id AS team_id, t.team_name, t.college, t.project_title
    FROM teams t JOIN users u ON u.id = t.user_id
    WHERE u.status = 'approved'`).all();
  const evals = db.prepare('SELECT * FROM evaluations').all();
  const assigned = db.prepare('SELECT team_id, COUNT(*) AS c FROM judge_assignments GROUP BY team_id').all();
  const assignedMap = Object.fromEntries(assigned.map((a) => [a.team_id, a.c]));

  const rows = teams.map((t) => {
    const mine = evals.filter((e) => e.team_id === t.team_id);
    const r1 = mine.filter((e) => e.round === 1);
    const r2 = mine.filter((e) => e.round === 2);
    const finalRound = r2.length ? 2 : r1.length ? 1 : null;
    const src = finalRound === 2 ? r2 : r1;
    const breakdown = {};
    CRITERIA.forEach((c) => { breakdown[c.key] = src.length ? avg(src.map((e) => e[c.key])) : null; });
    const round1 = avg(r1.map((e) => e.total));
    const round2v = avg(r2.map((e) => e.total));
    return {
      ...t,
      judges_assigned: assignedMap[t.team_id] || 0,
      r1_count: r1.length,
      r2_count: r2.length,
      round1,
      round2: round2v,
      final: finalRound === 2 ? round2v : round1,
      final_round: finalRound,
      breakdown
    };
  });

  rows.sort((a, b) => ((b.final ?? -1) - (a.final ?? -1)) || a.team_name.localeCompare(b.team_name));
  let rank = 0, prev = null;
  rows.forEach((r, i) => {
    if (r.final === null) { r.rank = null; return; }
    if (r.final !== prev) { rank = i + 1; prev = r.final; }
    r.rank = rank;
  });
  return rows;
}

module.exports = { leaderboard, avg };
