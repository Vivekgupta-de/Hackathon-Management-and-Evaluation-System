require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');
require('./db'); // creates tables + admin account

const app = express();
app.use(express.json({ limit: '1mb' }));

app.use('/api', require('./routes/auth'));
app.use('/api', require('./routes/otp')); // must stay above routes/common (which requires login for everything under /api)
app.use('/api/team', require('./routes/team'));
app.use('/api/mentor', require('./routes/mentor'));
app.use('/api/judge', require('./routes/judge'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api', require('./routes/common'));

app.use(express.static(path.join(__dirname, 'public')));

// unknown /api paths -> JSON 404
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

// one place that turns errors into JSON messages the frontend can show
app.use((err, req, res, next) => {
  if (err.code === 'LIMIT_FILE_SIZE') return res.status(400).json({ error: 'File is too large (max 10 MB)' });
  if (err.status) return res.status(err.status).json({ error: err.message });
  if (err.code === 'SQLITE_CONSTRAINT_UNIQUE' || /UNIQUE constraint/.test(err.message || '')) return res.status(409).json({ error: 'That value is already in use' });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server' });
});

const server = http.createServer(app);
const io = new Server(server);
require('./socket')(io);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n  Hackathon system running at http://localhost:${PORT}\n`);
});
