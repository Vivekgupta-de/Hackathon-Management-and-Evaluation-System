// Shared input validation. Every function throws a 400 error with a friendly message.
const { httpError } = require('./utils');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE = /^\d{10}$/;                       // exactly 10 digits, nothing else
const LINKEDIN_RE = /^https?:\/\/((www|[a-z]{2,3})\.)?linkedin\.com\/in\/[^\s\/?#]+\/?([?#]\S*)?$/i;
const GENDERS = ['Female', 'Male', 'Other'];

exports.GENDERS = GENDERS;

exports.normalizeEmail = (v, label = 'Email') => {
  const e = String(v ?? '').trim().toLowerCase();
  if (!EMAIL_RE.test(e)) throw httpError(400, `${label}: please enter a valid email address`);
  return e;
};

exports.normalizePhone = (v, label = 'Mobile number') => {
  const p = String(v ?? '').trim();
  if (!PHONE_RE.test(p)) throw httpError(400, `${label} must be exactly 10 digits (numbers only)`);
  return p;
};

// LinkedIn is always optional: empty -> null. Otherwise it must be a linkedin.com/in/... profile link.
exports.normalizeLinkedIn = (v, label = 'LinkedIn') => {
  let u = String(v ?? '').trim();
  if (!u) return null;
  if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
  if (u.length > 250 || !LINKEDIN_RE.test(u))
    throw httpError(400, `${label}: enter your profile link like https://www.linkedin.com/in/your-name (or leave it empty)`);
  return u;
};

exports.normalizeGender = (v, label = 'Gender') => {
  const g = String(v ?? '').trim();
  const match = GENDERS.find((x) => x.toLowerCase() === g.toLowerCase());
  if (!match) throw httpError(400, `${label}: please select Female, Male or Other`);
  return match;
};

exports.validatePassword = (v) => {
  if (String(v ?? '').length < 6) throw httpError(400, 'Password must be at least 6 characters');
  return String(v);
};
