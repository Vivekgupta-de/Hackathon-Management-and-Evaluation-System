exports.httpError = (status, message) => {
  const e = new Error(message);
  e.status = status;
  return e;
};

exports.need = (body, fields) => {
  const missing = fields.filter((f) => !String(body[f] ?? '').trim());
  if (missing.length) throw exports.httpError(400, `Please fill in: ${missing.join(', ')}`);
};

// Express 4 does not catch errors thrown inside async handlers - this wrapper forwards them
// to the central error handler in server.js.
exports.wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

// Tiny in-memory rate limiter (per IP). Good enough for a single-server hackathon site.
exports.rateLimit = ({ windowMs, max, message }) => {
  const hits = new Map();
  setInterval(() => {
    const now = Date.now();
    for (const [k, v] of hits) if (v.reset <= now) hits.delete(k);
  }, windowMs).unref();
  return (req, res, next) => {
    const now = Date.now();
    const key = req.ip || 'unknown';
    let h = hits.get(key);
    if (!h || h.reset <= now) { h = { count: 0, reset: now + windowMs }; hits.set(key, h); }
    h.count += 1;
    if (h.count > max) return next(exports.httpError(429, message || 'Too many requests. Please try again later.'));
    next();
  };
};
