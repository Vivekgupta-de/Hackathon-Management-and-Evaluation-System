const router = require('express').Router();
const fs = require('fs');
const path = require('path');
const db = require('../db');
const CRITERIA = require('../criteria');
const { leaderboard } = require('../scoring');
const { authRequired, role } = require('../middleware/auth');
const { httpError } = require('../utils');

router.use(authRequired, role('admin'));

router.get('/stats', (req, res) => {
  const count = (sql, ...p) => db.prepare(sql).get(...p).c;
  const byRole = (r) => ({
    total: count('SELECT COUNT(*) c FROM users WHERE role=?', r),
    pending: count("SELECT COUNT(*) c FROM users WHERE role=? AND status='pending'", r),
    approved: count("SELECT COUNT(*) c FROM users WHERE role=? AND status='approved'", r),
    rejected: count("SELECT COUNT(*) c FROM users WHERE role=? AND status='rejected'", r)
  });
  res.json({
    teams: byRole('team'), mentors: byRole('mentor'), judges: byRole('judge'),
    submissions: count('SELECT COUNT(*) c FROM submissions'),
    evaluations: count('SELECT COUNT(*) c FROM evaluations'),
    settings: { current_round: Number(db.getSetting('current_round')), results_published: db.getSetting('results_published') === '1' }
  });
});

router.get('/teams', (req, res) => {
  const teams = db.prepare(`
    SELECT t.*, u.id AS user_id, u.name AS leader_name, u.email, u.phone, u.linkedin AS leader_linkedin, u.email_verified, u.phone_verified, u.status, u.created_at, m.name AS mentor_name
    FROM teams t JOIN users u ON u.id=t.user_id LEFT JOIN users m ON m.id=t.mentor_id ORDER BY t.id DESC`).all();
  teams.forEach((t) => {
    t.members = db.prepare('SELECT name,gender,email,phone,linkedin FROM team_members WHERE team_id=?').all(t.id);
    t.judges = db.prepare('SELECT u.id,u.name FROM judge_assignments a JOIN users u ON u.id=a.judge_id WHERE a.team_id=?').all(t.id);
  });
  res.json(teams);
});

router.get('/mentors', (req, res) => res.json(db.prepare(`
  SELECT u.id,u.name,u.email,u.phone,u.linkedin,u.email_verified,u.phone_verified,u.status,u.created_at,m.organization,m.designation,m.skills,m.experience_years,m.experience_desc,m.availability,
    (SELECT COUNT(*) FROM teams WHERE mentor_id=u.id) AS team_count
  FROM users u JOIN mentors m ON m.user_id=u.id ORDER BY u.id DESC`).all()));

router.get('/judges', (req, res) => res.json(db.prepare(`
  SELECT u.id,u.name,u.email,u.phone,u.linkedin,u.email_verified,u.phone_verified,u.status,u.created_at,j.organization,j.designation,j.expertise,j.experience_years,j.experience_desc,
    (SELECT COUNT(*) FROM judge_assignments WHERE judge_id=u.id) AS team_count
  FROM users u JOIN judges j ON j.user_id=u.id ORDER BY u.id DESC`).all()));

// Approve / Reject / set back to pending  (works for teams, mentors and judges)
router.put('/users/:id/status', (req, res) => {
  const { status } = req.body;
  if (!['pending', 'approved', 'rejected'].includes(status)) throw httpError(400, 'Invalid status');
  const r = db.prepare("UPDATE users SET status=? WHERE id=? AND role != 'admin'").run(status, Number(req.params.id));
  if (!r.changes) throw httpError(404, 'User not found');
  res.json({ message: `Status set to ${status}` });
});

router.delete('/users/:id', (req, res) => {
  const id = Number(req.params.id);
  const u = db.prepare('SELECT role FROM users WHERE id=?').get(id);
  if (!u || u.role === 'admin') throw httpError(404, 'User not found');
  const files = db.prepare('SELECT s.file_path FROM submissions s JOIN teams t ON t.id=s.team_id WHERE t.user_id=? AND s.file_path IS NOT NULL').all(id);
  db.prepare('DELETE FROM users WHERE id=?').run(id);
  files.forEach((f) => fs.unlink(path.join(__dirname, '..', 'uploads', f.file_path), () => {}));
  res.json({ message: 'Deleted' });
});

router.put('/teams/:id/mentor', (req, res) => {
  const mentorId = req.body.mentor_id ? Number(req.body.mentor_id) : null;
  if (mentorId && !db.prepare("SELECT 1 FROM users WHERE id=? AND role='mentor' AND status='approved'").get(mentorId))
    throw httpError(400, 'Choose an approved mentor');
  const r = db.prepare('UPDATE teams SET mentor_id=? WHERE id=?').run(mentorId, Number(req.params.id));
  if (!r.changes) throw httpError(404, 'Team not found');
  res.json({ message: mentorId ? 'Mentor assigned' : 'Mentor removed' });
});

router.put('/teams/:id/judges', (req, res) => {
  const teamId = Number(req.params.id);
  const ids = (req.body.judge_ids || []).map(Number);
  if (!db.prepare('SELECT 1 FROM teams WHERE id=?').get(teamId)) throw httpError(404, 'Team not found');
  db.tx(() => {
    db.prepare('DELETE FROM judge_assignments WHERE team_id=?').run(teamId);
    const ins = db.prepare('INSERT INTO judge_assignments(judge_id,team_id) VALUES(?,?)');
    ids.forEach((jid) => {
      if (!db.prepare("SELECT 1 FROM users WHERE id=? AND role='judge' AND status='approved'").get(jid)) throw httpError(400, 'Only approved judges can be assigned');
      ins.run(jid, teamId);
    });
  });
  res.json({ message: 'Judges updated' });
});

router.get('/submissions', (req, res) => res.json(db.prepare(`
  SELECT s.id,s.title,s.original_name,s.link,s.created_at,t.team_name,t.id AS team_id
  FROM submissions s JOIN teams t ON t.id=s.team_id ORDER BY s.id DESC`).all()));

router.get('/evaluations', (req, res) => res.json(db.prepare(`
  SELECT e.*, t.team_name, j.name AS judge_name
  FROM evaluations e JOIN teams t ON t.id=e.team_id JOIN users j ON j.id=e.judge_id
  ORDER BY t.team_name, e.round, j.name`).all()));

router.get('/leaderboard', (req, res) => res.json({ criteria: CRITERIA, rows: leaderboard() }));

router.get('/report.csv', (req, res) => {
  const rows = leaderboard();
  const q = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const head = ['Rank', 'Team', 'College', 'Project', 'Judges scored (R1)', 'Judges scored (R2)', 'Round 1 avg /100', 'Round 2 avg /100', 'FINAL /100', ...CRITERIA.map((c) => `${c.label} /${c.max}`)];
  const lines = [head.map(q).join(',')];
  rows.forEach((r) => lines.push([r.rank ?? '', r.team_name, r.college, r.project_title, r.r1_count, r.r2_count, r.round1 ?? '', r.round2 ?? '', r.final ?? '', ...CRITERIA.map((c) => r.breakdown[c.key] ?? '')].map(q).join(',')));
  res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="hackathon-results.csv"' });
  res.send('\uFEFF' + lines.join('\r\n'));
});

router.put('/settings', (req, res) => {
  const { current_round, results_published } = req.body;
  if (![1, 2].includes(Number(current_round))) throw httpError(400, 'Round must be 1 or 2');
  db.setSetting('current_round', Number(current_round));
  db.setSetting('results_published', results_published ? 1 : 0);
  res.json({ message: 'Settings saved' });
});

module.exports = router;
