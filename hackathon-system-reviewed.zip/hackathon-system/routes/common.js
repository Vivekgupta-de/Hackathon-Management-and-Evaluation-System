// Routes shared by several roles: protected file download + list of video rooms.
const router = require('express').Router();
const path = require('path');
const db = require('../db');
const { authRequired } = require('../middleware/auth');
const { roomsFor } = require('../rooms');
const { httpError } = require('../utils');

router.use(authRequired);

router.get('/submissions/:id/download', (req, res) => {
  const s = db.prepare('SELECT s.*, t.user_id AS team_user, t.mentor_id FROM submissions s JOIN teams t ON t.id=s.team_id WHERE s.id=?').get(Number(req.params.id));
  if (!s || !s.file_path) throw httpError(404, 'File not found');
  const u = req.user;
  const allowed =
    u.role === 'admin' ||
    (u.role === 'team' && s.team_user === u.id) ||
    (u.role === 'mentor' && s.mentor_id === u.id) ||
    (u.role === 'judge' && db.prepare('SELECT 1 FROM judge_assignments WHERE judge_id=? AND team_id=?').get(u.id, s.team_id));
  if (!allowed) throw httpError(403, 'You cannot download this file');
  res.download(path.join(__dirname, '..', 'uploads', s.file_path), s.original_name || s.file_path);
});

router.get('/video/rooms', (req, res) => res.json(roomsFor(req.user)));

module.exports = router;
