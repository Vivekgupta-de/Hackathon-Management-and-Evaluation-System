const router = require('express').Router();
const db = require('../db');
const upload = require('../upload');
const fs = require('fs');
const CRITERIA = require('../criteria');
const { leaderboard } = require('../scoring');
const { authRequired, role } = require('../middleware/auth');
const { httpError, need } = require('../utils');

router.use(authRequired, role('team'));

router.get('/me', (req, res) => {
  const user = db.prepare('SELECT name,email,phone,linkedin,status FROM users WHERE id = ?').get(req.user.id);
  const team = db.prepare('SELECT * FROM teams WHERE user_id = ?').get(req.user.id);
  const members = db.prepare('SELECT name,gender,email,phone,linkedin FROM team_members WHERE team_id = ?').all(team.id);
  const mentor = team.mentor_id
    ? db.prepare(`SELECT u.name,u.email,u.phone,u.linkedin,m.skills,m.organization FROM users u LEFT JOIN mentors m ON m.user_id=u.id WHERE u.id=?`).get(team.mentor_id)
    : null;
  const submissions = db.prepare('SELECT id,title,original_name,link,created_at FROM submissions WHERE team_id = ? ORDER BY id DESC').all(team.id);
  const published = db.getSetting('results_published') === '1';

  let results = null;
  if (published) {
    const board = leaderboard().find((r) => r.team_id === team.id);
    // judge identities are hidden from teams
    const evals = db.prepare('SELECT * FROM evaluations WHERE team_id = ? ORDER BY round, id').all(team.id)
      .map(({ judge_id, ...rest }) => rest);
    results = { summary: board || null, evaluations: evals, criteria: CRITERIA };
  }
  res.json({ user, team, members, mentor, submissions, results, current_round: Number(db.getSetting('current_round')), results_published: published });
});

router.put('/idea', (req, res) => {
  need(req.body, ['project_title', 'project_idea']);
  db.prepare('UPDATE teams SET project_title=?, project_idea=? WHERE user_id=?').run(req.body.project_title.trim(), req.body.project_idea.trim(), req.user.id);
  res.json({ message: 'Project idea updated' });
});

router.post('/submissions', upload.single('file'), (req, res) => {
  try {
    need(req.body, ['title']);
    const link = String(req.body.link || '').trim();
    if (!req.file && !link) throw httpError(400, 'Upload a file or paste a link (GitHub, Drive, YouTube...)');
    if (link && !/^https?:\/\//i.test(link)) throw httpError(400, 'Link must start with http:// or https://');
    const team = db.prepare('SELECT id FROM teams WHERE user_id = ?').get(req.user.id);
    db.prepare('INSERT INTO submissions(team_id,title,file_path,original_name,link) VALUES(?,?,?,?,?)')
      .run(team.id, req.body.title.trim(), req.file ? req.file.filename : null, req.file ? req.file.originalname : null, link || null);
    res.status(201).json({ message: 'Submission added' });
  } catch (e) {
    if (req.file) fs.unlink(req.file.path, () => {});
    throw e;
  }
});

module.exports = router;
