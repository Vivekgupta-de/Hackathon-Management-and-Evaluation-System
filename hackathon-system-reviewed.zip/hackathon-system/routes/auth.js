const router = require('express').Router();
const bcrypt = require('bcryptjs');
const fs = require('fs');
const db = require('../db');
const upload = require('../upload');
const otp = require('../otp');
const CRITERIA = require('../criteria');
const { sign, authRequired } = require('../middleware/auth');
const { httpError, need } = require('../utils');
const { normalizeEmail, normalizePhone, normalizeLinkedIn, normalizeGender, validatePassword } = require('../validators');

// Creates the account. Email and mobile must both have been verified with an OTP (tokens come from /api/otp/verify).
function createUser({ name, email, password, phone, linkedin, role, email_token, phone_token }) {
  email = normalizeEmail(email);
  phone = normalizePhone(phone);
  validatePassword(password);
  linkedin = normalizeLinkedIn(linkedin);
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) throw httpError(409, 'This email is already registered');
  if (db.prepare('SELECT 1 FROM users WHERE phone = ?').get(phone)) throw httpError(409, 'This mobile number is already registered');
  otp.assertVerified(email_token, 'email', email, 'register');
  otp.assertVerified(phone_token, 'phone', phone, 'register');
  const r = db.prepare('INSERT INTO users(name,email,password,phone,linkedin,email_verified,phone_verified,role,status) VALUES(?,?,?,?,?,1,1,?,?)')
    .run(String(name).trim(), email, bcrypt.hashSync(String(password), 10), phone, linkedin, role, 'pending');
  return Number(r.lastInsertRowid);
}

// ---- public info ----
router.get('/criteria', (req, res) => res.json(CRITERIA));
router.get('/settings', (req, res) => res.json({
  current_round: Number(db.getSetting('current_round')),
  results_published: db.getSetting('results_published') === '1'
}));

// ---- Team registration (multipart form: fields + optional document) ----
router.post('/register/team', upload.single('document'), (req, res) => {
  try {
    const b = req.body;
    need(b, ['leader_name', 'leader_gender', 'email', 'password', 'phone', 'team_name', 'college', 'department', 'problem_statement', 'project_title', 'project_idea']);
    const leaderGender = normalizeGender(b.leader_gender, 'Team leader gender');

    let raw = [];
    try { raw = JSON.parse(b.members || '[]'); } catch (e) { throw httpError(400, 'Team member data is invalid'); }
    const members = raw.filter((m) => m && String(m.name || '').trim()).map((m, i) => {
      const label = `Member ${i + 1}`;
      const phone = String(m.phone || '').trim();
      const email = String(m.email || '').trim();
      return {
        name: String(m.name).trim(),
        gender: normalizeGender(m.gender, `${label} gender`),
        phone: phone ? normalizePhone(phone, `${label} mobile number`) : null,
        email: email ? normalizeEmail(email, `${label} email`) : null,
        linkedin: normalizeLinkedIn(m.linkedin, `${label} LinkedIn`)
      };
    });
    if (members.length < 1 || members.length > 3) throw httpError(400, 'Add 1 to 3 team members in addition to the team leader (team size 2-4)');

    // Rule: at least one female member in every team (leader or any member)
    if (![leaderGender, ...members.map((m) => m.gender)].includes('Female'))
      throw httpError(400, 'Every team must include at least 1 female member (the team leader or any member).');

    if (db.prepare('SELECT 1 FROM teams WHERE lower(team_name) = lower(?)').get(b.team_name.trim())) throw httpError(409, 'This team name is already taken');

    db.tx(() => {
      const userId = createUser({ name: b.leader_name, email: b.email, password: b.password, phone: b.phone, linkedin: b.linkedin, role: 'team', email_token: b.email_token, phone_token: b.phone_token });
      const t = db.prepare(`INSERT INTO teams(user_id,team_name,college,department,city,problem_statement,project_title,project_idea,leader_gender)
        VALUES(?,?,?,?,?,?,?,?,?)`).run(userId, b.team_name.trim(), b.college.trim(), b.department.trim(), (b.city || '').trim() || null,
        b.problem_statement.trim(), b.project_title.trim(), b.project_idea.trim(), leaderGender);
      const teamId = Number(t.lastInsertRowid);
      const ins = db.prepare('INSERT INTO team_members(team_id,name,gender,email,phone,linkedin) VALUES(?,?,?,?,?,?)');
      members.forEach((m) => ins.run(teamId, m.name, m.gender, m.email, m.phone, m.linkedin));
      if (req.file) {
        db.prepare('INSERT INTO submissions(team_id,title,file_path,original_name) VALUES(?,?,?,?)')
          .run(teamId, 'Registration document', req.file.filename, req.file.originalname);
      }
    });
    res.status(201).json({ message: 'Team registered! The organisers will review and approve your team soon. You can log in now to track your status.' });
  } catch (e) {
    if (req.file) fs.unlink(req.file.path, () => {});
    throw e;
  }
});

// ---- Mentor registration ----
router.post('/register/mentor', (req, res) => {
  const b = req.body;
  need(b, ['name', 'email', 'password', 'phone', 'organization', 'skills', 'availability']);
  db.tx(() => {
    const id = createUser({ ...b, role: 'mentor' });
    db.prepare('INSERT INTO mentors(user_id,organization,designation,skills,experience_years,experience_desc,availability) VALUES(?,?,?,?,?,?,?)')
      .run(id, b.organization.trim(), (b.designation || '').trim() || null, b.skills.trim(), Number(b.experience_years) || 0, (b.experience_desc || '').trim() || null, b.availability.trim());
  });
  res.status(201).json({ message: 'Mentor application received. Your status is Pending until the admin approves it.' });
});

// ---- Judge registration ----
router.post('/register/judge', (req, res) => {
  const b = req.body;
  need(b, ['name', 'email', 'password', 'phone', 'organization', 'expertise']);
  db.tx(() => {
    const id = createUser({ ...b, role: 'judge' });
    db.prepare('INSERT INTO judges(user_id,organization,designation,expertise,experience_years,experience_desc) VALUES(?,?,?,?,?,?)')
      .run(id, b.organization.trim(), (b.designation || '').trim() || null, b.expertise.trim(), Number(b.experience_years) || 0, (b.experience_desc || '').trim() || null);
  });
  res.status(201).json({ message: 'Judge application received. Your status is Pending until the admin approves it.' });
});

// ---- Login (one endpoint, role chosen on the login page) ----
router.post('/login', (req, res) => {
  const { email, password, role } = req.body;
  need(req.body, ['email', 'password', 'role']);
  const u = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email).trim().toLowerCase());
  if (!u || !bcrypt.compareSync(String(password), u.password)) throw httpError(401, 'Incorrect email or password');
  if (u.role !== role) throw httpError(403, `This account is a ${u.role} account. Please use the "${u.role}" tab to log in.`);
  if (u.status === 'rejected') throw httpError(403, 'Your registration was rejected. Please contact the organisers.');
  res.json({ token: sign(u), user: { id: u.id, name: u.name, email: u.email, role: u.role, status: u.status } });
});

router.get('/me', authRequired, (req, res) => {
  const u = db.prepare('SELECT id,name,email,role,status FROM users WHERE id = ?').get(req.user.id);
  if (!u) throw httpError(401, 'Account not found');
  res.json(u);
});

module.exports = router;
