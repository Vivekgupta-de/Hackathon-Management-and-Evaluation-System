const router = require('express').Router();
const db = require('../db');
const { authRequired, role } = require('../middleware/auth');

router.use(authRequired, role('mentor'));

router.get('/me', (req, res) => {
  const user = db.prepare('SELECT u.name,u.email,u.phone,u.linkedin,u.status,m.* FROM users u LEFT JOIN mentors m ON m.user_id=u.id WHERE u.id=?').get(req.user.id);
  let teams = [];
  if (user.status === 'approved') {
    teams = db.prepare(`SELECT t.*, u.name AS leader_name, u.email AS leader_email, u.phone AS leader_phone, u.linkedin AS leader_linkedin
      FROM teams t JOIN users u ON u.id=t.user_id WHERE t.mentor_id=? ORDER BY t.team_name`).all(req.user.id);
    teams.forEach((t) => {
      t.members = db.prepare('SELECT name,email,phone,linkedin FROM team_members WHERE team_id=?').all(t.id);
      t.submissions = db.prepare('SELECT id,title,original_name,link,created_at FROM submissions WHERE team_id=? ORDER BY id DESC').all(t.id);
    });
  }
  res.json({ user, teams });
});

module.exports = router;
