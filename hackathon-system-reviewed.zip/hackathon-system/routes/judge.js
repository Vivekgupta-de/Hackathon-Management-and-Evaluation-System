const router = require('express').Router();
const db = require('../db');
const CRITERIA = require('../criteria');
const { authRequired, role } = require('../middleware/auth');
const { httpError } = require('../utils');

router.use(authRequired, role('judge'));

const currentRound = () => Number(db.getSetting('current_round'));

router.get('/me', (req, res) => {
  const user = db.prepare('SELECT u.name,u.email,u.phone,u.linkedin,u.status,j.* FROM users u LEFT JOIN judges j ON j.user_id=u.id WHERE u.id=?').get(req.user.id);
  let teams = [];
  if (user.status === 'approved') {
    teams = db.prepare(`SELECT t.*, u.name AS leader_name FROM teams t
      JOIN judge_assignments a ON a.team_id=t.id JOIN users u ON u.id=t.user_id
      WHERE a.judge_id=? AND u.status='approved' ORDER BY t.team_name`).all(req.user.id);
    teams.forEach((t) => {
      t.members = db.prepare('SELECT name FROM team_members WHERE team_id=?').all(t.id);
      t.submissions = db.prepare('SELECT id,title,original_name,link FROM submissions WHERE team_id=? ORDER BY id DESC').all(t.id);
      t.evaluations = db.prepare('SELECT * FROM evaluations WHERE judge_id=? AND team_id=?').all(req.user.id, t.id);
    });
  }
  res.json({ user, teams, criteria: CRITERIA, current_round: currentRound() });
});

router.post('/evaluate', (req, res) => {
  const me = db.prepare('SELECT status FROM users WHERE id=?').get(req.user.id);
  if (!me || me.status !== 'approved') throw httpError(403, 'Your judge account is not approved yet');

  const teamId = Number(req.body.team_id);
  const round = Number(req.body.round);
  const scores = req.body.scores || {};
  if (round !== currentRound()) throw httpError(400, `Scoring is currently open for Round ${currentRound()} only`);
  if (!db.prepare('SELECT 1 FROM judge_assignments WHERE judge_id=? AND team_id=?').get(req.user.id, teamId))
    throw httpError(403, 'This team is not assigned to you');

  const vals = {};
  let total = 0;
  for (const c of CRITERIA) {
    const v = Number(scores[c.key]);
    if (scores[c.key] === '' || scores[c.key] === undefined || !Number.isInteger(v) || v < 0 || v > c.max)
      throw httpError(400, `${c.label}: enter a whole number from 0 to ${c.max}`);
    vals[c.key] = v;
    total += v;
  }
  db.prepare(`INSERT INTO evaluations(judge_id,team_id,round,problem,innovation,technical,feasibility,prototype,impact,presentation,total,feedback,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
    ON CONFLICT(judge_id,team_id,round) DO UPDATE SET
      problem=excluded.problem, innovation=excluded.innovation, technical=excluded.technical, feasibility=excluded.feasibility,
      prototype=excluded.prototype, impact=excluded.impact, presentation=excluded.presentation, total=excluded.total,
      feedback=excluded.feedback, updated_at=CURRENT_TIMESTAMP`)
    .run(req.user.id, teamId, round, vals.problem, vals.innovation, vals.technical, vals.feasibility, vals.prototype, vals.impact, vals.presentation, total, String(req.body.feedback || '').trim());
  res.json({ message: `Saved. Total for this team: ${total}/100`, total });
});

module.exports = router;
