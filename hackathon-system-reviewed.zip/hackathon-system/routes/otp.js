// OTP endpoints: verify email/phone during registration, and the forgot-password flow.
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const otp = require('../otp');
const { httpError, wrap, rateLimit } = require('../utils');
const { normalizeEmail, normalizePhone, validatePassword } = require('../validators');

router.use(['/otp', '/forgot-password'], rateLimit({ windowMs: 10 * 60 * 1000, max: 200, message: 'Too many attempts. Please wait a few minutes and try again.' }));

const CHANNELS = ['email', 'phone'];
const targetOf = (channel, raw) => (channel === 'email' ? normalizeEmail(raw) : normalizePhone(raw));

// ---------- Registration: send + verify ----------
router.post('/otp/send', wrap(async (req, res) => {
  const { channel, target: raw } = req.body;
  if (!CHANNELS.includes(channel)) throw httpError(400, 'Invalid channel');
  const target = targetOf(channel, raw);
  const taken = channel === 'email'
    ? db.prepare('SELECT 1 FROM users WHERE email=?').get(target)
    : db.prepare('SELECT 1 FROM users WHERE phone=?').get(target);
  if (taken) throw httpError(409, channel === 'email' ? 'This email is already registered. Try logging in.' : 'This mobile number is already registered. Try logging in.');
  const r = await otp.issue(channel, target, 'register');
  res.json({ message: `OTP sent to your ${channel === 'email' ? 'email' : 'mobile number'}`, ...r });
}));

router.post('/otp/verify', wrap(async (req, res) => {
  const { channel, target: raw, code } = req.body;
  if (!CHANNELS.includes(channel)) throw httpError(400, 'Invalid channel');
  const target = targetOf(channel, raw);
  otp.verify(channel, target, 'register', code);
  res.json({ message: channel === 'email' ? 'Email verified' : 'Mobile number verified', token: otp.verifiedToken(channel, target, 'register') });
}));

// ---------- Forgot password ----------
// The reply never reveals whether an account exists.
router.post('/forgot-password/send', wrap(async (req, res) => {
  const channel = CHANNELS.includes(req.body.channel) ? req.body.channel : 'email';
  const email = normalizeEmail(req.body.email);
  const generic = { message: 'If an account exists for this email, an OTP has been sent.' };
  const u = db.prepare('SELECT email, phone FROM users WHERE email=?').get(email);
  const target = u && (channel === 'email' ? u.email : u.phone);
  if (!target) return res.json(generic);
  try {
    const r = await otp.issue(channel, target, 'reset');
    res.json({ ...generic, dev: r.dev, resend_after_seconds: r.resend_after_seconds });
  } catch (e) {
    if (e.status === 429 || e.status === 502) return res.json(generic); // do not leak account existence via errors
    throw e;
  }
}));

router.post('/forgot-password/reset', wrap(async (req, res) => {
  const channel = CHANNELS.includes(req.body.channel) ? req.body.channel : 'email';
  const email = normalizeEmail(req.body.email);
  const password = validatePassword(req.body.password);
  const u = db.prepare('SELECT id, email, phone FROM users WHERE email=?').get(email);
  const target = u && (channel === 'email' ? u.email : u.phone);
  if (!target) throw httpError(400, 'Incorrect or expired OTP. Please request a new one.');
  otp.verify(channel, target, 'reset', req.body.code);
  const col = channel === 'email' ? 'email_verified' : 'phone_verified';
  db.prepare(`UPDATE users SET password=?, ${col}=1 WHERE id=?`).run(bcrypt.hashSync(password, 10), u.id);
  res.json({ message: 'Password changed. You can now log in with your new password.' });
}));

module.exports = router;
