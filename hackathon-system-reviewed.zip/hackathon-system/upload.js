const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const { httpError } = require('./utils');

const ALLOWED = ['.pdf', '.ppt', '.pptx', '.doc', '.docx', '.zip', '.png', '.jpg', '.jpeg', '.txt'];

module.exports = multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, 'uploads'),
    filename: (req, file, cb) => cb(null, Date.now() + '-' + crypto.randomBytes(6).toString('hex') + path.extname(file.originalname).toLowerCase())
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    ALLOWED.includes(ext) ? cb(null, true) : cb(httpError(400, 'File type not allowed. Use PDF, PPT, DOC, ZIP or images (max 10 MB).'));
  }
});
