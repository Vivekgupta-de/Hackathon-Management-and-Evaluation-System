// Database layer. Uses better-sqlite3 when available, otherwise Node's built-in node:sqlite (Node 22+).
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');

const file = path.join(__dirname, 'data', 'hackathon.db');
fs.mkdirSync(path.dirname(file), { recursive: true });

let db;
try {
  const Database = require('better-sqlite3');
  db = new Database(file);
  db.pragma('journal_mode = WAL');
} catch (e) {
  const { DatabaseSync } = require('node:sqlite');
  db = new DatabaseSync(file);
}
db.exec('PRAGMA foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  phone TEXT,
  role TEXT NOT NULL CHECK (role IN ('team','mentor','judge','admin')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS teams (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  team_name TEXT NOT NULL UNIQUE,
  college TEXT NOT NULL,
  department TEXT,
  city TEXT,
  problem_statement TEXT,
  project_title TEXT,
  project_idea TEXT,
  mentor_id INTEGER REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS team_members (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT
);
CREATE TABLE IF NOT EXISTS mentors (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  organization TEXT,
  designation TEXT,
  skills TEXT,
  experience_years INTEGER,
  experience_desc TEXT,
  availability TEXT
);
CREATE TABLE IF NOT EXISTS judges (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  organization TEXT,
  designation TEXT,
  expertise TEXT,
  experience_years INTEGER,
  experience_desc TEXT
);
CREATE TABLE IF NOT EXISTS judge_assignments (
  judge_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  team_id INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  PRIMARY KEY (judge_id, team_id)
);
CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  file_path TEXT,
  original_name TEXT,
  link TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS evaluations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  judge_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  team_id INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  round INTEGER NOT NULL CHECK (round IN (1,2)),
  problem INTEGER NOT NULL,
  innovation INTEGER NOT NULL,
  technical INTEGER NOT NULL,
  feasibility INTEGER NOT NULL,
  prototype INTEGER NOT NULL,
  impact INTEGER NOT NULL,
  presentation INTEGER NOT NULL,
  total INTEGER NOT NULL,
  feedback TEXT,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (judge_id, team_id, round)
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);
CREATE TABLE IF NOT EXISTS otps (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel TEXT NOT NULL CHECK (channel IN ('email','phone')),
  target TEXT NOT NULL,
  purpose TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  used INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_otps_lookup ON otps(channel, target, purpose, id);
`);

// ---- Upgrades for databases created by an older version (safe to run every start) ----
function addColumn(table, column, ddl) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all();
  if (!cols.some((c) => c.name === column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${ddl}`);
}
addColumn('users', 'linkedin', 'TEXT');
addColumn('users', 'email_verified', 'INTEGER NOT NULL DEFAULT 0');
addColumn('users', 'phone_verified', 'INTEGER NOT NULL DEFAULT 0');
addColumn('teams', 'leader_gender', 'TEXT');
addColumn('team_members', 'gender', 'TEXT');
addColumn('team_members', 'linkedin', 'TEXT');

// Run several statements as one all-or-nothing transaction.
db.tx = (fn) => {
  db.exec('BEGIN');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
};

db.getSetting = (key) => {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
};
db.setSetting = (key, value) => {
  db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, String(value));
};

// Defaults
if (db.getSetting('current_round') === null) db.setSetting('current_round', 1);
if (db.getSetting('results_published') === null) db.setSetting('results_published', 0);

// Create the admin account on first run
const adminEmail = (process.env.ADMIN_EMAIL || 'admin@hackathon.com').toLowerCase();
if (!db.prepare("SELECT 1 FROM users WHERE role='admin'").get()) {
  db.prepare("INSERT INTO users(name,email,password,role,status) VALUES(?,?,?,?,?)").run(
    process.env.ADMIN_NAME || 'Hackathon Admin',
    adminEmail,
    bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'Admin@123', 10),
    'admin',
    'approved'
  );
  console.log(`Admin account created: ${adminEmail}`);
}

module.exports = db;
